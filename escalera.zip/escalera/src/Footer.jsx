import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-left">
      <p>&copy; {new Date().getFullYear()} CCIT Alumni Connect. </p>
        <p>Privacy Policy</p>
      </div>
      <div className="footer-right">
        <p>
          National University<br />
          551 M.F. Jhocson St. Sampaloc, Manila, PH 1008<br />
          +632 8712-1900
        </p>
        <p>
          Alumni Affairs<br />
          +632 8563-6991<br />
          alumni-affairs@national-u.edu.ph
        </p>
      </div>
    </footer>
  );
}

export default Footer;
<p>&copy; {new Date().getFullYear()} CCIT Alumni Connect. </p>