import React from 'react';
import './Body.css';

function Body() {
  return (
    <main className="Body">
      <div className="Body-left">
        <img
          src="/WhiteLogo.png" // Ensure this image is in the public folder
          alt="CCIT National University Logo"
          className="ccit-logo"
        />
        <h1>National University</h1>
        <div className="buttons">
          <button className="join-button">Join Now!</button>
          <button className="login-button">Login</button>
        </div>
      </div>
      <div className="Body-right">
        <img
          src="/nu-background.png" // Ensure this image is in the public folder
          alt="124 Years Logo"
          className="years-logo"
        />
        <p>Honoring years of Education that works.</p>
      </div>
    </main>
  );
}

export default MainContent;