import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">CCIT Alumni</div>
      <nav className="nav-menu">
        <a href="#home">Home</a>
        <a href="#about">About Us</a>
        <a href="#events">Events</a>
        <a href="#mentors">Mentors</a>
        <a href="#achievements">Achievements</a>
        <a href="#contact">Contact Us</a>
      </nav>
    </header>
  );
};

export default Header;