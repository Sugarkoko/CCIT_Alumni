import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg6.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg6 = () => {
  const navigate = useNavigate();
  const [isChecked, setIsChecked] = useState(false);

  const handleBack = () => {
    navigate("/social-links");
  };

  const handleSubmit = () => {
    if (isChecked) {
      console.log("Form submitted");
      navigate("/verify-account"); 
    }
  };

  const handleCheckboxChange = (e) => {
    setIsChecked(e.target.checked); 
  };

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-header">
          <div className="signup-header-row">
            <img src={logo} alt="Blue Logo" className="signup-logo" />
            <h1>Alumni Sign up Form</h1>
          </div>
        </div>
        <div className="signup-form">
          <p>
            I hereby agree, that I permit the NU Alumni Affairs Office-Manila to share my email address
            (only) to my respective college program (i.e., College of Business and Accountancy, College of Architecture).
            This aims to receive updates from respective colleges regarding upcoming activities.
          </p>
          <p>
            I hereby agree that the above information is true and correct to the best of my knowledge. 
            I hereby authorize the NU Alumni Affairs Office to connect with me through the details indicated 
            above for upcoming events, promotions, and updates regarding my Alma Mater, the National University.
          </p>
          <div className="signup-checkbox">
            <input
              type="checkbox"
              id="agree"
              name="agree"
              onChange={handleCheckboxChange} 
            />
            <label htmlFor="agree">I agree.</label>
          </div>
        </div>
        <div className="signup-actions">
          <button className="back-btn" onClick={handleBack}>
            Back
          </button>
          <button
            className="next-btn"
            onClick={handleSubmit}
            disabled={!isChecked} 
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reg6;
