import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg3.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg3 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    age: "",
    sexAtBirth: "",
    contactNumber: "",
    emailAddress: "",
    currentAddress: "",
  });
  const [error, setError] = useState(""); // State for error message

  const handleBack = () => {
    navigate("/registration-details");
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
    setError(""); // Clear the error message on input change
  };

  const isFormComplete =
    formData.age.trim() &&
    formData.sexAtBirth &&
    formData.contactNumber.trim() &&
    formData.emailAddress.trim() &&
    formData.currentAddress.trim();

  const handleNext = () => {
    // Check if email ends with @gmail.com
    if (!formData.emailAddress.endsWith("@gmail.com")) {
      setError("Email address must end with '@gmail.com'.");
      return;
    }

    // Navigate to the next page if everything is valid
    if (isFormComplete) {
      navigate("/final-details");
    }
  };

  return (
    <div
      className="signup-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>5. Age</label>
            <input
              type="text"
              name="age"
              value={formData.age}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>6. Sex at birth</label>
            <div>
              <label>
                <input
                  type="radio"
                  name="sexAtBirth"
                  value="Female"
                  onChange={handleInputChange}
                  checked={formData.sexAtBirth === "Female"}
                />
                Female
              </label>
              <label>
                <input
                  type="radio"
                  name="sexAtBirth"
                  value="Male"
                  onChange={handleInputChange}
                  checked={formData.sexAtBirth === "Male"}
                />
                Male
              </label>
            </div>

            <label>7. Contact Number (Mobile)</label>
            <input
              type="text"
              name="contactNumber"
              value={formData.contactNumber}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>8. Personal Email Address</label>
            <input
              type="text"
              name="emailAddress"
              value={formData.emailAddress}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />
            {error && <p className="error-message">{error}</p>}

            <label>9. Current Address</label>
            <input
              type="text"
              name="currentAddress"
              value={formData.currentAddress}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleNext}
                disabled={!isFormComplete}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg3;