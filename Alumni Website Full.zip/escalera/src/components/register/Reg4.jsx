import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg4.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg4 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    citizenship: "",
    presentWork: "",
    position: "",
    alumniActivities: [],
    otherActivity: "",
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    if (checked) {
      setFormData({
        ...formData,
        alumniActivities: [...formData.alumniActivities, name],
      });
    } else {
      setFormData({
        ...formData,
        alumniActivities: formData.alumniActivities.filter(
          (activity) => activity !== name
        ),
      });
    }
  };

  const handleBack = () => {
    navigate("/additional-details");
  };

  const handleSubmit = () => {
    navigate("/social-links"); 
  };

  const isFormComplete =
    formData.citizenship.trim() &&
    formData.presentWork.trim() &&
    formData.position.trim();

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>10. Citizenship</label>
            <input
              type="text"
              name="citizenship"
              value={formData.citizenship}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>11. Present Work / Company</label>
            <input
              type="text"
              name="presentWork"
              value={formData.presentWork}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>12. Position (Title)</label>
            <input
              type="text"
              name="position"
              value={formData.position}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>13. Alumni activities I would like to get notified</label>
            <div>
              <label>
                <input
                  type="checkbox"
                  name="Alumni Reunions"
                  onChange={handleCheckboxChange}
                />
                Alumni Reunions
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Volunteer Programs"
                  onChange={handleCheckboxChange}
                />
                Volunteer Programs
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Interest Groups"
                  onChange={handleCheckboxChange}
                />
                Interest Groups (e.g., Auto Club, Biker's Club, Golf Club, Entrepreneurs Club)
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Mentoring Programs"
                  onChange={handleCheckboxChange}
                />
                Mentoring Programs (e.g., Talks, Featured Alumni, Guest Speakers)
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Partnerships and Sponsorships"
                  onChange={handleCheckboxChange}
                />
                Partnerships and Sponsorships
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Career Fairs"
                  onChange={handleCheckboxChange}
                />
                Career Fairs
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Other"
                  onChange={handleCheckboxChange}
                />
                Other
              </label>
              {formData.alumniActivities.includes("Other") && (
                <input
                  type="text"
                  name="otherActivity"
                  value={formData.otherActivity}
                  placeholder="Specify other activity"
                  onChange={handleInputChange}
                />
              )}
            </div>
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleSubmit}
                disabled={!isFormComplete}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg4;