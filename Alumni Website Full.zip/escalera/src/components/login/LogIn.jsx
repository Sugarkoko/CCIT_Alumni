import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import './LogIn.css';
import background from '../../assets-login/BackgroundCover.jpeg';
import logo from '../../assets-login/Blue Logo.png';

const LogIn = () => {
  const [emailPlaceholder, setEmailPlaceholder] = useState('Enter email address');
  const [passwordPlaceholder, setPasswordPlaceholder] = useState('Enter password');
  const [confirmPasswordPlaceholder, setConfirmPasswordPlaceholder] = useState('Confirm password');

  const navigate = useNavigate();
  const location = useLocation();

  // Where did the user come from?
  const from = location.state?.from;

  const handleLogin = (e) => {
    e.preventDefault();
    navigate('/authentication', { state: { from } }); // Pass 'from' to Authentication
  };

  const handleCancel = () => {
        // If we have a 'from' state, go there. Otherwise, go back in history
        if (from) {
            navigate(from, { replace: true });
        } else {
            navigate(-1);
        }
  };

  return (
    <div className="login-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="login-overlay">
        <div className="login-header">
          <img src={logo} alt="Logo" className="login-logo" />
          <h1>Login</h1>
        </div>
        <form className="login-form" onSubmit={handleLogin}>
          <input
            type="email"
            placeholder={emailPlaceholder}
            className="styled-input"
            onFocus={() => setEmailPlaceholder('')}
            onBlur={() => setEmailPlaceholder('Enter email address')}
            required
          />
          <input
            type="password"
            placeholder={passwordPlaceholder}
            className="styled-input"
            onFocus={() => setPasswordPlaceholder('')}
            onBlur={() => setPasswordPlaceholder('Enter password')}
            required
          />
          <input
            type="password"
            placeholder={confirmPasswordPlaceholder}
            className="styled-input"
            onFocus={() => setConfirmPasswordPlaceholder('')}
            onBlur={() => setConfirmPasswordPlaceholder('Confirm password')}
            required
          />
          <Link to="/reset-password" className="forgot-password">
            Forgot password?
          </Link>
          <div className="login-actions">
            <button type="button" className="cancel-btn" onClick={handleCancel}>
              Cancel
            </button>
            <button type="submit" className="login-btn">Login</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LogIn;