import React from 'react';
import { Link } from 'react-router-dom';
import nuBackgroundPng from '../../assets-homepage/nu-background.png';
import './Body.css';

const Body = () => {

  return (
    <div>
      <main className="body" style={{ backgroundImage: `url(${nuBackgroundPng})` }}>
        <section className="content">
          <h2>Welcome to National University Alumni Portal</h2>
          <p>Join us and stay connected with the CCIT alumni community.</p>
          <div className="buttons">
            <Link to="/register" className="join-btn">
              Join Now!
            </Link>
            <Link to="/login" className="login-btn">
              Login
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Body;