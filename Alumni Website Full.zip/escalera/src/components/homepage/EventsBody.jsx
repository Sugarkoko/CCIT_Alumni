import React from 'react';
import { Link } from 'react-router-dom';
import './EventsBody.css';

const EventsBody = () => {
  return (
    <div className="events-body-container">
      <h1 className="events-title">Join the CCIT Alumni Connect Community!</h1>
      <p className="events-description">
        Access to the Events Page is limited to verified alumni members. Want
        to stay connected and see what's happening?{' '}
        <Link to="/register" className="register-link">
          Register
        </Link>{' '}
        as an alumni member today!
      </p>
      <Link to="/register" className="join-button">
        Join Now!
      </Link>
      <p className="login-text">
        Already a member?{' '}
        <Link to="/login" className="login-link">
          Login
        </Link>
      </p>
    </div>
  );
};

export default EventsBody;