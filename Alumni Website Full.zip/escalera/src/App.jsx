import React from 'react';
import Header from './components/homepage/Header';
import Body from './components/homepage/Body';
import EventsBody from './components/homepage/EventsBody';
import Footer from './components/homepage/Footer';
import AchBody from './components/homepage/AchBody';
import AboutBody from './components/homepage/AboutBody';
import ContactBody from './components/homepage/ContactBody';
import LogIn from './components/login/LogIn';
import ResetPass from './components/login/ResetPass';
import Authentication from './components/login/Authentication';
import Reg1 from './components/register/Reg1';
import Reg2 from './components/register/Reg2';
import Reg3 from './components/register/Reg3';
import Reg4 from './components/register/Reg4';
import Reg5 from './components/register/Reg5';
import Reg6 from './components/register/Reg6';
import Reg7 from './components/register/Reg7';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <Routes>
          <Route path="/" element={<Body />} />
          <Route path="/events" element={<EventsBody />} />
          <Route path="/achievements" element={<AchBody />} />
          <Route path="/about" element={<AboutBody />} />
          <Route path="/contact" element={<ContactBody />} />
          <Route path="/login" element={<LogIn />} />
          <Route path="/reset-password" element={<ResetPass />} />
          <Route path="/authentication" element={<Authentication />} />
          <Route path="/test-route" element={<h1>Test Route Works!</h1>} />
<Route path="/register" element={<Reg1 />} /> {/* Your register route - keep this */}
          <Route path="/register" element={<Reg1 />} /> {/* Route for Reg1 */}
          <Route path="/registration-details" element={<Reg2 />} /> {/* Route for Reg2 */}
          <Route path="/additional-details" element={<Reg3 />} />
          <Route path="/final-details" element={<Reg4 />} />
          <Route path="/social-links" element={<Reg5 />} />
          <Route path="/review-form" element={<Reg6 />} />
          <Route path="/verify-account" element={<Reg7 />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;