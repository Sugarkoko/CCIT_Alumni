# .gitignore

```
# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*

node_modules
dist
dist-ssr
*.local

# Editor directories and files
.vscode/*
!.vscode/extensions.json
.idea
.DS_Store
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?

```

# eslint.config.js

```js
import js from '@eslint/js'
import globals from 'globals'
import react from 'eslint-plugin-react'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'

export default [
  { ignores: ['dist'] },
  {
    files: ['**/*.{js,jsx}'],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
      parserOptions: {
        ecmaVersion: 'latest',
        ecmaFeatures: { jsx: true },
        sourceType: 'module',
      },
    },
    settings: { react: { version: '18.3' } },
    plugins: {
      react,
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
    },
    rules: {
      ...js.configs.recommended.rules,
      ...react.configs.recommended.rules,
      ...react.configs['jsx-runtime'].rules,
      ...reactHooks.configs.recommended.rules,
      'react/jsx-no-target-blank': 'off',
      'react-refresh/only-export-components': [
        'warn',
        { allowConstantExport: true },
      ],
    },
  },
]

```

# index.html

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CCIT Alumni</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>

```

# package.json

```json
{
  "name": "escalera",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "lint": "eslint .",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router-dom": "^7.1.2"
  },
  "devDependencies": {
    "@eslint/js": "^9.17.0",
    "@types/react": "^18.3.18",
    "@types/react-dom": "^18.3.5",
    "@vitejs/plugin-react": "^4.3.4",
    "eslint": "^9.17.0",
    "eslint-plugin-react": "^7.37.2",
    "eslint-plugin-react-hooks": "^5.0.0",
    "eslint-plugin-react-refresh": "^0.4.16",
    "globals": "^15.14.0",
    "vite": "^6.0.5"
  }
}

```

# README.md

```md
# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

```

# src\App.css

```css
.app {
  font-family: 'Inter', sans-serif;
  margin: 0;
  padding: 0;
}


```

# src\App.jsx

```jsx
import React from 'react';
import Header from './components/homepage/Header';
import Body from './components/homepage/Body';
import EventsBody from './components/homepage/EventsBody';
import Footer from './components/homepage/Footer';
import AchBody from './components/homepage/AchBody';
import AboutBody from './components/homepage/AboutBody';
import ContactBody from './components/homepage/ContactBody';
import LogIn from './components/login/LogIn';
import ResetPass from './components/login/ResetPass';
import Authentication from './components/login/Authentication';
import Reg1 from './components/register/Reg1';
import Reg2 from './components/register/Reg2';
import Reg3 from './components/register/Reg3';
import Reg4 from './components/register/Reg4';
import Reg5 from './components/register/Reg5';
import Reg6 from './components/register/Reg6';
import Reg7 from './components/register/Reg7';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <Routes>
          <Route path="/" element={<Body />} />
          <Route path="/events" element={<EventsBody />} />
          <Route path="/achievements" element={<AchBody />} />
          <Route path="/about" element={<AboutBody />} />
          <Route path="/contact" element={<ContactBody />} />
          <Route path="/login" element={<LogIn />} />
          <Route path="/reset-password" element={<ResetPass />} />
          <Route path="/authentication" element={<Authentication />} />
          <Route path="/test-route" element={<h1>Test Route Works!</h1>} />
<Route path="/register" element={<Reg1 />} /> {/* Your register route - keep this */}
          <Route path="/register" element={<Reg1 />} /> {/* Route for Reg1 */}
          <Route path="/registration-details" element={<Reg2 />} /> {/* Route for Reg2 */}
          <Route path="/additional-details" element={<Reg3 />} />
          <Route path="/final-details" element={<Reg4 />} />
          <Route path="/social-links" element={<Reg5 />} />
          <Route path="/review-form" element={<Reg6 />} />
          <Route path="/verify-account" element={<Reg7 />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
```

# src\assets-homepage\acads.png

This is a binary file of the type: Image

# src\assets-homepage\BlueLogo.png

This is a binary file of the type: Image

# src\assets-homepage\enyu.webp

This is a binary file of the type: Image

# src\assets-homepage\enyu1.jpg

This is a binary file of the type: Image

# src\assets-homepage\enyu2.jpg

This is a binary file of the type: Image

# src\assets-homepage\nu-background.png

This is a binary file of the type: Image

# src\assets-homepage\sports.png

This is a binary file of the type: Image

# src\assets-homepage\trophy.png

This is a binary file of the type: Image

# src\assets-homepage\WhiteLogo.png

This is a binary file of the type: Image

# src\assets-login\BackgroundCover.jpeg

This is a binary file of the type: Image

# src\assets-login\backLogo.png

This is a binary file of the type: Image

# src\assets-login\Blue Logo.png

This is a binary file of the type: Image

# src\assets-register\Background.jpeg

This is a binary file of the type: Image

# src\assets-register\backLogo.png

This is a binary file of the type: Image

# src\assets-register\Blue Logo.png

This is a binary file of the type: Image

# src\components\homepage\AboutBody.css

```css
.main-content {
    display: flex;
    justify-content: center;  
    align-items: center;  
    flex-direction: column;   
    padding: 100px;            
    height: auto;             
    margin-bottom: 50px;
    margin-top: -120px;
    text-align: center;
  }
  
  .logo {
    width: 300px;
    margin-top: 0;            
    margin-bottom: 10px;     
    margin-left: auto;
    margin-right: auto;
  }
  
  .main-content p {
    text-align: justify;
    justify-content: center;
    margin: 0 auto;       
    max-width: 750px;
    line-height: 2.5;
    margin-top: 40px;
    margin-bottom: 10px;
    font-family: Inter, sans-serif;
  }
  
  .logo-line {
    width: 80%;              
    border: 2px solid #FFCC00; 
    margin: 10px auto;        
    margin-top: -80px;        
    margin-bottom: 30px;
  }
  
```

# src\components\homepage\AboutBody.jsx

```jsx
import React from "react";
import BlueLogo from '../../assets-homepage/BlueLogo.png'; // Path to assets-homepage
import "./AboutBody.css";


function AboutBody(){
  return (
    <main className="main-content">
      <img src={BlueLogo} alt="CCIT Logo" className="logo" />
      <hr className="logo-line" /> 
      <p>
        The Alumni Management System website offers an intuitive and user-friendly platform for CCIT alumni to connect with each other and the university. 
        Featuring a centralized database, real-time notifications, event management tools, and a mentorship matching system, the website ensures seamless 
        interaction and engagement. Alumni can update their profiles, register for events, participate in mentorship programs, and access exclusive benefits, all within a secure and efficient digital environment.
      </p>
      <p>
        It is designed to bridge the gap between the College of Computing and Information Technology (CCIT) alumni and National University-Manila. 
        Its purpose is to streamline communication, enhance engagement, and foster a stronger, more connected alumni network.  By providing a centralized platform for managing alumni data, organizing events, facilitating mentorship opportunities, and showcasing achievements, the system aims to create a vibrant community where alumni can stay informed, contribute to the university, and support the growth of current students.
      </p>
    </main>
  );
};

export default AboutBody;
```

# src\components\homepage\AchBody.css

```css
.header-image {
  transition: opacity 1s ease-in-out;
}

.achievements-frame {
    font-family: Arial, sans-serif;
    color: #333;
    background-color: #f9f9f9;

  }
  
  .achievements-header {
    position: relative;
    text-align: center;
    color: rgb(255, 255, 255);
  }
  
  .header-image {
    width: 100%;
    height: 60vh;
    object-fit: fill;
  }
  
  .achievements-header h1 {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 2.5rem;
    font-weight: bold;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }
  
  .achievements-content {
    padding: 20px;
  }
  
  .achievements-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
  }
  
  .achievement-card {
    background-color: #ffc107;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 300px;
    text-align: center;
  }
  
  .achievement-card img {
    width: 50px;
    margin-bottom: 15px;
  }
  
  .achievement-card p {
    font-size: 1rem;
    line-height: 1.5;
  }
```

# src\components\homepage\AchBody.jsx

```jsx
import React, { useState, useEffect } from 'react';
import enyuWebp from "../../assets-homepage/enyu.webp";
import enyu1Jpg from '../../assets-homepage/enyu1.jpg';
import enyu2Jpg from '../../assets-homepage/enyu2.jpg';
import acadsPng from '../../assets-homepage/acads.png';
import sportsPng from '../../assets-homepage/sports.png';
import trophyPng from '../../assets-homepage/trophy.png';
import './AchBody.css';

function AchBody() {
  const images = [enyuWebp, enyu1Jpg, enyu2Jpg];
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const autoSlide = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3000); 
    return () => clearInterval(autoSlide); 
  }, [images.length]);

  return (
    <main className="achievements-frame">
      <div className="achievements-header">
        <img
          src={images[currentIndex]}
          alt="National University"
          className="header-image"
        />
        <h1>National University</h1>
      </div>
      <section className="achievements-content">
        <div className="achievements-container">
          <div className="achievement-card">
          <img src={acadsPng} alt="Academic Icon" />
            <p>
              National University (NU), established on August 1, 1900, recently
              celebrated its 122nd founding anniversary, marking over a century
              of academic excellence and dedicated educational service.
            </p>
          </div>
          <div className="achievement-card">
          <img src={sportsPng} alt="Sports Icon" />
            <p>
              As a founding member of the University Athletic Association of
              the Philippines (UAAP), NU’s varsity teams, known as the Bulldogs,
              have consistently excelled in various sports.
            </p>
          </div>
          <div className="achievement-card">
          <img src={trophyPng} alt="Award Icon" />
            <p>
              National University (NU) Manila has been recognized for its
              dedication to academic equity and excellence, receiving four
              prestigious awards from PACUCOA.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}

export default AchBody;
```

# src\components\homepage\Body.css

```css
.body {
  position: relative; 
  width: 100%;
  height: 100vh; 
  background: url('nu-background.png') no-repeat center center/cover; 
  display: flex;
  justify-content: center; 
  align-items: flex-start;
  padding: 20px; 
  box-sizing: border-box;
}

.content {
  position: relative; 
  margin-top: 8vh;
  transform: translateX(-330px);
  color: white;
  background-color: rgba(0, 0, 0, 0.6); 
  padding: 30px; 
  border-radius: 10px; 
  text-align: left;
  max-width: 550px; 
  width: 90%;
}

.content h2 {
  font-size: 1.8rem;
  margin-bottom: 15px;
}

.content p {
  margin-bottom: 20px;
  font-size: 1.1rem; 
}

.buttons {
  display: flex;
  gap: 15px; 
}

.join-btn, .login-btn {
  padding: 12px 24px; 
  border: none;
  background-color: #ffcc00; 
  color: #002f6c;
  font-weight: bold;
  cursor: pointer;
  border-radius: 5px;
  transition: background-color 0.3s ease;
}

.join-btn:hover, .login-btn:hover {
  background-color: #e6b800; 
}


@media (max-width: 768px) {
  .content {
    margin-top: 5vh; 
    max-width: 90%; 
  }

  .content h2 {
    font-size: 1.5rem; 
  }

  .content p {
    font-size: 1rem;
  }

  .join-btn, .login-btn {
    padding: 10px 20px; 
    font-size: 1rem;
  }
}

```

# src\components\homepage\Body.jsx

```jsx
import React from 'react';
import { Link } from 'react-router-dom';
import nuBackgroundPng from '../../assets-homepage/nu-background.png';
import './Body.css';

const Body = () => {

  return (
    <div>
      <main className="body" style={{ backgroundImage: `url(${nuBackgroundPng})` }}>
        <section className="content">
          <h2>Welcome to National University Alumni Portal</h2>
          <p>Join us and stay connected with the CCIT alumni community.</p>
          <div className="buttons">
            <Link to="/register" className="join-btn">
              Join Now!
            </Link>
            <Link to="/login" className="login-btn">
              Login
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Body;
```

# src\components\homepage\ContactBody.css

```css
.contact-section {
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin: 20px;
    padding: 20px;
    margin-top: 0;
  }
  
  .contact-container {
    display: flex;
    justify-content: space-between;
    gap: 100px;
    margin-left: 150px;
  }
  
  .contact-details h3, .alumni-affairs h3, .ccit-contact h3, .map-container h3, .main-content h3 {
    font-size: 1.5em;
    color: #333;
    margin-bottom: 0;
    font-family: Inter, sans-serif;
  }
  
  .contact-details p, .alumni-affairs p, .ccit-contact p, .main-content p {
    margin: 5px 0;
    font-size: 0.95em;
    color: #555;
    font-family: Inter, sans-serif;
  }
  
  .main-content h3 {
    margin-top: 10px;
    margin-bottom: 30px;
  }
  
  
  .contact-divider {
    width: 100%;
    height: 3px;
    background-color: #FFCC00; 
    margin-top: 30px; 
    margin-bottom: 0;
  }
  
  .location-container {
    display: flex;
    gap: 50px;
  }
  
  .main-content {
    flex: 1;
  }
  
  .map-container {
    flex: 1;
    margin-top: 30px;
  }
  
  .map-container h3 {
  margin-bottom: 10px;
  margin-top: 30px;
  }
  
  .main-content h3 {
    font-size: 2em;
    margin-bottom: 10px;
  }
  
  .main-content p {
    text-align: justify;
    margin-bottom: 15px;
  }
  
  .map-container {
    width: 100%; 
    margin-top: 20px; 
  }
  
  .map-container iframe {
    width: 100%; 
    height: 800px; 
    border: none; 
  }
  
  
```

# src\components\homepage\ContactBody.jsx

```jsx
import React from "react";
import "./ContactBody.css";

function ContactBody() {
  return (
    <div className="contact-section">
      <div className="contact-container">
        <div className="contact-details">
          <h3>National University</h3>
          <p>📍 551 M.F. Jhocson St. Sampaloc, Manila, PH 1008</p>
          <p>📞 +632 8712-1900</p>
          <p>
            ✉️ <a href="mailto:info@national-u.edu.ph">info@national-u.edu.ph</a>
          </p>
        </div>

        <div className="alumni-affairs">
          <h3>Alumni Affairs</h3>
          <p>📞 +632 8563-6991</p>
          <p>
            ✉️{" "}
            <a href="mailto:alumni-affairs@national-u.edu.ph">
              alumni-affairs@national-u.edu.ph
            </a>
          </p>
          <p>College of Computing and Information Technologies</p>
          <p>📞 +632 8712-1900</p>
        </div>

        <div className="ccit-contact">
          <h3>College of Computing and Information Technologies</h3>
          <p>📞 +632 8712-1900</p>
        </div>
      </div>

      <div className="contact-divider"></div>

      <div className="location-container">
        <div className="main-content">
          <h3>University Location</h3>
          <p>
            The University can easily be reached from any part of the City of
            Manila by using the ordinary means of transportation.
          </p>
          <p>
            From Quiapo, one may take a jeepney plying the Quiapo Lealtad route
            at Barbosa Street in Quiapo and then alight at a point on F.
            Jhocson: if preferred, one may take a Balic-Balic bound jeepney and
            alight at the corner of G. Tuazon and M. F. Jhocson Streets.
          </p>
          <p>
            The University may also be reached by way of España Street from
            points North or Northwest through Cayco Street, then turn right
            through F. Jhocson Street to M. F. Jhocson Street; from points
            Northwest through Earnshaw Street, turn left through Cayco then
            right through F. Jhocson to M. F. Jhocson.
          </p>
          <p>
            From Antipolo, Cainta, Marikina, Pasig, and surrounding communities,
            the University can be reached by taking the LRT Marikina Santolan
            Station and alight at the Legarda Station, then proceed towards the
            Sampaloc church, turn right to F. Jhocson Street.
          </p>
        </div>

        <div className="map-container">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3858.045412571616!2d120.98985731485862!3d14.607751489793033!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b610d7ec7edb%3A0x7c2b7d8f9e332d9b!2s551%20M.F.%20Jhocson%20St.%2C%20Sampaloc%2C%20Manila%2C%20PH%201008!5e0!3m2!1sen!2sph!4v1618305532061!5m2!1sen!2sph"
            width="100%"
            height="400"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
          ></iframe>
        </div>
      </div>
    </div>
  );
}

export default ContactBody;
```

# src\components\homepage\EventsBody.css

```css


.events-body-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 20px;
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
  height: 100vh;
}

.events-title {
  font-size: 3.8rem;
  font-weight: bold;
  color: #000;
  margin-bottom: 20px;

}

.events-description {
  font-size: 1.8rem;
  color: #333;
  margin-bottom: 30px;
  max-width: 800px;
}

.register-link {
  color: #007bff;
  font-weight: bold;
  cursor: pointer;
}

.register-link:hover {
  text-decoration: underline;
}

.join-button {
  background-color: #ffc107;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-bottom: 20px;
}

.join-button:hover {
  background-color: #e0a800;
}

.login-text {
  font-size: 14px;
  color: #555;
}

.login-link {
  color: #007bff;
  font-weight: bold;
  cursor: pointer;
}

.login-link:hover {
  text-decoration: underline;
}

  
```

# src\components\homepage\EventsBody.jsx

```jsx
import React from 'react';
import { Link } from 'react-router-dom';
import './EventsBody.css';

const EventsBody = () => {
  return (
    <div className="events-body-container">
      <h1 className="events-title">Join the CCIT Alumni Connect Community!</h1>
      <p className="events-description">
        Access to the Events Page is limited to verified alumni members. Want
        to stay connected and see what's happening?{' '}
        <Link to="/register" className="register-link">
          Register
        </Link>{' '}
        as an alumni member today!
      </p>
      <Link to="/register" className="join-button">
        Join Now!
      </Link>
      <p className="login-text">
        Already a member?{' '}
        <Link to="/login" className="login-link">
          Login
        </Link>
      </p>
    </div>
  );
};

export default EventsBody;
```

# src\components\homepage\Footer.css

```css
.footer {
    background-color: #172D75;
    color: white;
    display: flex;
    justify-content: space-between;
    padding: 45px;
    font-family: Inter;
    width: 100%; 
    box-sizing: border-box; 
    align-items: flex-start; 
    font-family: Inter, sans-serif;
  }
  
  .footer-section {
    text-align: left;
    margin: 0;
  }
```

# src\components\homepage\Footer.jsx

```jsx
import React from 'react';
import './Footer.css'

function Footer() {
    return (
        <footer className="footer">
          <div className="footer-section">
            <p>&copy;{new Date().getFullYear()} CCIT Alumni Connect. All rights reserved.</p>
            <p>Privacy Policy</p>
          </div>
          <div className="footer-section">
            <p>College of Computing and Information Technologies</p>
            <p>📞 +632 8712-1900</p>
          </div>
          <div className="footer-section">
            <p>Alumni Affairs</p>
            <p>📞 +632 8563-6991</p>
            <p><a href="mailto:alumni-affairs@national-u.edu.ph">📧 alumni-affairs@national-u.edu.ph</a></p>
          </div>
        </footer>
      );
    };
    
    export default Footer;
```

# src\components\homepage\Header.css

```css
.header {
    background-color: #172D75; 
    color: white;
    font-family: Inter, sans-serif;
    padding: 0;
}

.header-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1px 20px; 
}

.header-logo img {
    height: 100px; 
    object-fit: contain;
}

.header-title {
    font-size: 2.0 rem; 
    font-family: Raleway, sans-serif;
    font-weight: bold;
    text-align: center;
    flex-grow: 1; 
    margin: 0;
}

.header-nav {
    background-color: #C9B42F; 
    width: 100%; 
    display: flex;
    justify-content: center;
    padding: 10px 0; 
    box-sizing: border-box;
    margin: 0;
}

.header-nav ul {
    list-style: none;
    display: flex;
    gap: 150px; 
    padding: 0;
    margin: 0;
    align-items: center;
}

.header-nav li {
    display: inline;
}

.header-nav a {
    text-decoration: none;
    color: white; 
    font-size: 1rem;
    transition: color 0.3s ease;
}

.header-nav a:hover {
    text-decoration: underline; 
}

```

# src\components\homepage\Header.jsx

```jsx
import React from 'react';
import { Link } from 'react-router-dom';
import WhiteLogoPng from '../../assets-homepage/WhiteLogo.png';
import './Header.css'

function Header() {
    return (
        <header className="header">
            <div className="header-container">
                <div className="header-logo">
                <img src={WhiteLogoPng} alt="CCIT Logo" />
            </div>
            <div className="header-title">
                    COLLEGE OF COMPUTING AND INFORMATION TECHNOLOGIES ALUMNI
                </div>
                </div>
            <nav className="header-nav">
                <ul>
                    <li><Link to ="/">Home</Link></li>
                    <li><Link to ="/about">About us</Link></li>
                    <li><Link to ="/events">Events</Link></li>
                    <li><Link to ="/achievements">Achievements</Link></li>
                    <li><Link to ="/contact">Contact us</Link></li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;
```

# src\components\login\Authentication.css

```css
.auth-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.auth-overlay {
    background: rgba(255, 255, 255, 0.85);
    width: 350px;
    padding: 40px;
    border-radius: 50px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
    text-align: center;
    max-height: 85%;
    overflow-y: auto;
}

.auth-header h1 {
    margin-bottom: 20px;
    font-size: 1.5rem;
    font-weight: bold;
    font-family: Inter, sans-serif;
    color: #172D75;
    text-shadow: 
        -1px -1px 0 #fff, 
        1px -1px 0 #fff,  
        -1px 1px 0 #fff,  
        1px 1px 0 #fff;
}

.auth-content p {
    margin-bottom: 15px;
    font-size: 0.9rem;
    color: #444;
    font-family: Inter, sans-serif;
}

.auth-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.auth-input {
    padding: 12px;
    font-size: 20px;
    text-align: center;
    letter-spacing: 10px;
    border: 1px solid #ccc;
    border-radius: 10px;
    background-color: rgba(255, 255, 255, 0.1);
    transition: border-color 0.3s, background-color 0.3s;
}

.auth-input:focus {
    border-color: rgba(0, 86, 179, 0.7);
    background-color: rgba(255, 255, 255, 0.1);
    outline: none;
}

.auth-note {
    font-size: 0.8rem;
    color: #635858;
    font-family: Inter, sans-serif;
    margin-top: -10px;
    text-align: left;
}

.auth-note a {
    color: #172D75;
    text-decoration: none;
    font-weight: bold;
}

.auth-note a:hover {
    text-decoration: underline;
}


.auth-btn,
.back-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    border: none;
    border-radius: 8px;
    color: white;
    background-color: #172d75;
    cursor: pointer;
    transition: background-color 0.3s;
}


.auth-btn:hover,
.back-btn:hover {
    background-color: #0056b3;
}


.auth-buttons {
    display: flex;
    justify-content: center; 
    gap: 10px; 
    margin-top: 20px; 
}

.popup {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 300px;
    padding: 20px;
    background: white;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    text-align: center;
    z-index: 1000;
}

.popup p {
    font-size: 1rem;
    color: #444;
    margin-bottom: 20px;
    font-family: Inter, sans-serif;
}

.popup-btn {
    padding: 10px 15px;
    font-size: 14px;
    font-weight: bold;
    color: white;
    background-color: #172d75;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

.popup-btn:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .auth-overlay {
        width: 90%;
        padding: 20px;
    }

    .auth-input {
        font-size: 14px;
        padding: 8px;
    }

    .auth-btn, .back-btn {
        font-size: 14px;
        padding: 10px;
    }

    .auth-buttons {
        gap: 8px; 
    }
}

@media (max-width: 480px) {
    .auth-overlay {
        border-radius: 30px;
    }

    .auth-input {
        font-size: 12px;
    }

    .auth-btn, .back-btn {
        padding: 8px;
    }
}

```

# src\components\login\Authentication.jsx

```jsx
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Authentication.css';
import background from '../../assets-login/BackgroundCover.jpeg';

const Authentication = () => {
  const [verificationCode, setVerificationCode] = useState('');
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Keep track of where we came from
  const from = location.state?.from;

  const handleBackClick = () => {
    // Go back to Login, pass the original 'from'
    navigate('/login', { replace: true, state: { from } });
  };

  const handleChange = (e) => {
    setVerificationCode(e.target.value);
  };

  const handleResend = () => {
    setIsPopupVisible(true);
    setTimeout(() => setIsPopupVisible(false), 3000);
  };

  return (
    <div className="auth-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="auth-overlay">
        <div className="auth-header">
          <h1>Enter Your 6-Digits Verification Code</h1>
        </div>
        <div className="auth-content">
          <p>
            For added security, we’ve sent a 6-digits verification code to your email.
          </p>
          <p>
            Please enter the code below to confirm your identity and continue accessing your account.
          </p>
          <form className="auth-form">
            <input
              type="text"
              maxLength="6"
              placeholder="______"
              value={verificationCode}
              onChange={handleChange}
              className="auth-input"
            />
            <p className="auth-note">
              Note: This code is only valid for 10 minutes. If you didn’t receive a code, please check your
              spam folder or request a new one. <a href="#resend" onClick={handleResend}>Resend</a>
            </p>
            <div className="auth-buttons">
              <button type="button" className="auth-btn back-btn" onClick={handleBackClick}>
                Back
              </button>
              <button type="submit" className="auth-btn">
                Done
              </button>
            </div>
          </form>
        </div>
      </div>
      {isPopupVisible && (
        <div className="popup">
          <p>
            A new verification code has been sent to your email. Please check your inbox and enter the code.
          </p>
          <button className="popup-btn" onClick={() => setIsPopupVisible(false)}>
            Done
          </button>
        </div>
      )}
    </div>
  );
};

export default Authentication;
```

# src\components\login\LogIn.css

```css
.login-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center; 
    align-items: center; 
}


.login-overlay {
    background: rgba(255, 255, 255, 0.70);
    width: 350px;
    padding: 50px;
    border-radius: 50px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
    text-align: center;
    max-height: 85%;
    overflow-y: auto;
}

.login-header {
    display: flex;
    align-items: center;
    justify-content: space-between; 
    margin-bottom: 20px;
    position: relative;
}

.login-logo {
    width: 90px;
    height: 95px;
    margin-left: 0; 
}

.login-header h1 {
    position: absolute;
    left: 50%;
    transform: translateX(-50%); 
    margin: 0;
    font-size: 1.5rem;
    font-weight: bold;
    font-family: Inter, sans-serif;
    color: #172D75;
    text-shadow: 
        -1px -1px 0 #fff, 
        1px -1px 0 #fff,  
        -1px 1px 0 #fff,  
        1px 1px 0 #fff;   
}

.login-form {
    display: flex;
    flex-direction: column;
    gap: 40px; 
    
}

.styled-input {
    padding: 12px;
    font-size: 16px;
    text-align: center; 
    border: 1px solid #ccc;
    border-radius: 10px;
    background-color: rgba(255, 255, 255, 0.10);
    transition: border-color 0.3s, background-color 0.3s;
}

.styled-input:focus {
    border-color: rgba(0, 86, 179, 0.7);
    background-color: rgba(255, 255, 255, 0.1);
    outline: none;
}

.forgot-password {
    font-size: 0.9rem;
    color: #635858;
    text-decoration: none;
    font-family: Inter, sans-serif;
    margin-top: -10px; 
    font-weight: bold;
}

.login-actions {
    display: flex;
    justify-content: space-between;
}

.cancel-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    background-color: #E71607;
    color: white;
    transition: background-color 0.3s;
}

.login-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    background-color: #172d75;
    color: white;
    transition: background-color 0.3s;
}

.cancel-btn:hover {
    background-color: #ff3e3e;
}

.login-btn:hover {
    background-color: #0056b3;
}

.forgot-password:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .login-overlay {
        width: 90%; 
        padding: 15px;
    }

    .login-header h1 {
        font-size: 1.2rem;
    }

    .styled-input {
        font-size: 14px;
        padding: 10px; 
    }

    .cancel-btn, .login-btn {
        font-size: 14px;
        padding: 10px;
    }
}

@media (max-width: 480px) {
    .login-overlay {
        width: 95%;
        padding: 10px;
        border-radius: 30px;
    }

    .login-header h1 {
        font-size: 1rem;
    }

    .styled-input {
        font-size: 12px;
        padding: 8px; 
    }

    .cancel-btn, .login-btn {
        font-size: 12px;
        padding: 8px;
    }
}
```

# src\components\login\LogIn.jsx

```jsx
import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import './LogIn.css';
import background from '../../assets-login/BackgroundCover.jpeg';
import logo from '../../assets-login/Blue Logo.png';

const LogIn = () => {
  const [emailPlaceholder, setEmailPlaceholder] = useState('Enter email address');
  const [passwordPlaceholder, setPasswordPlaceholder] = useState('Enter password');
  const [confirmPasswordPlaceholder, setConfirmPasswordPlaceholder] = useState('Confirm password');

  const navigate = useNavigate();
  const location = useLocation();

  // Where did the user come from?
  const from = location.state?.from;

  const handleLogin = (e) => {
    e.preventDefault();
    navigate('/authentication', { state: { from } }); // Pass 'from' to Authentication
  };

  const handleCancel = () => {
        // If we have a 'from' state, go there. Otherwise, go back in history
        if (from) {
            navigate(from, { replace: true });
        } else {
            navigate(-1);
        }
  };

  return (
    <div className="login-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="login-overlay">
        <div className="login-header">
          <img src={logo} alt="Logo" className="login-logo" />
          <h1>Login</h1>
        </div>
        <form className="login-form" onSubmit={handleLogin}>
          <input
            type="email"
            placeholder={emailPlaceholder}
            className="styled-input"
            onFocus={() => setEmailPlaceholder('')}
            onBlur={() => setEmailPlaceholder('Enter email address')}
            required
          />
          <input
            type="password"
            placeholder={passwordPlaceholder}
            className="styled-input"
            onFocus={() => setPasswordPlaceholder('')}
            onBlur={() => setPasswordPlaceholder('Enter password')}
            required
          />
          <input
            type="password"
            placeholder={confirmPasswordPlaceholder}
            className="styled-input"
            onFocus={() => setConfirmPasswordPlaceholder('')}
            onBlur={() => setConfirmPasswordPlaceholder('Confirm password')}
            required
          />
          <Link to="/reset-password" className="forgot-password">
            Forgot password?
          </Link>
          <div className="login-actions">
            <button type="button" className="cancel-btn" onClick={handleCancel}>
              Cancel
            </button>
            <button type="submit" className="login-btn">Login</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LogIn;
```

# src\components\login\ResetPass.css

```css
.resetpass-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.resetpass-overlay {
    background: rgba(255, 255, 255, 0.70);
    width: 350px;
    padding: 50px;
    border-radius: 50px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
    text-align: center;
    max-height: 85%;
    overflow-y: auto;
}

.resetpass-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
    margin-bottom: 20px;
}

.resetpass-logo {
    width: 90px;
    height: 95px;
    margin-left: 0;
}

.resetpass-header h1 {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    margin: 0;
    font-size: 1.5rem;
    font-weight: bold;
    font-family: Inter, sans-serif;
    color: #172D75;
    text-shadow: 
        -1px -1px 0 #fff, 
        1px -1px 0 #fff,  
        -1px 1px 0 #fff,  
        1px 1px 0 #fff;
}

.resetpass-form {
    display: flex;
    flex-direction: column;
    gap: 40px;
    font-family: Inter, sans-serif;
}

.styled-input {
    padding: 12px;
    font-size: 16px;
    text-align: center;
    border: 1px solid #ccc;
    border-radius: 10px;
    background-color: rgba(255, 255, 255, 0.10);
    transition: border-color 0.3s, background-color 0.3s;
}

.styled-input:focus {
    border-color: rgba(0, 86, 179, 0.7);
    background-color: rgba(255, 255, 255, 0.1);
    outline: none;
}

.resetpass-actions {
    display: flex;
    flex-direction: column;
    gap: 15px;
    padding: 20px ;
}

.reset-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    background-color: #172d75;
    color: white;
    transition: background-color 0.3s;
}

.cancel-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    background-color: #E71607;
    color: white;
    transition: background-color 0.3s;
}

.reset-btn:hover {
    background-color: #0056b3;
}

.cancel-btn:hover {
    background-color: #ff3e3e;
}

.popup-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  }
  
  .popup-content {
    background: white;
    padding: 20px 30px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 90%;
  }
  
  .popup-icon {
    font-size: 3rem;
    color: green;
    margin-bottom: 10px;
  }
  
  .popup-content h2 {
    font-size: 1.5rem;
    margin-bottom: 10px;
    color: black;
    font-family: Inter, sans-serif;
    font-weight: bold;
  }
  
  .popup-content p {
    font-size: 1rem;
    margin-bottom: 20px;
    color:black;
    font-family: Inter, sans-serif;
  }
  
  .close-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    color: white;
    background-color: #e71607;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .close-btn:hover {
    background-color: #ff3e3e;
  }
  

  @media (max-width: 768px) {
    .resetpass-overlay {
        width: 90%;
        padding: 20px;
    }

    .styled-input {
        font-size: 14px;
        padding: 8px;
    }

    .popup {
        width: 80%;
        max-width: 300px;
    }

    .resetpass-header h1 {
        font-size: 1.2rem;
    }
}

@media (max-width: 480px) {
    .resetpass-overlay {
        border-radius: 30px;
    }

    .styled-input {
        font-size: 12px;
    }
}
```

# src\components\login\ResetPass.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import "./ResetPass.css";
import background from '../../assets-login/BackgroundCover.jpeg';
import logo from "../../assets-login/Blue Logo.png";

const ResetPass = () => {
  const [emailPlaceholder, setEmailPlaceholder] = useState("Enter email address");
  const [showPopup, setShowPopup] = useState(false); 
  const navigate = useNavigate();

  const handleResetRequest = (e) => {
    e.preventDefault();
    setShowPopup(true); 
  };

  const handleClosePopup = () => {
    setShowPopup(false); // Close the popup
    // No navigation here - user stays on ResetPass.jsx
  };

  const handleCancel = () => {
    navigate("/login", { replace: true }); // Replace ResetPass with Login in history
  };

  return (
    <div
      className="resetpass-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="resetpass-overlay">
        <div className="resetpass-header">
          <img src={logo} alt="Logo" className="resetpass-logo" />
          <h1>Reset your password</h1>
        </div>
        <form className="resetpass-form">
          <p>
            Please enter the email address you'd like your password reset
            information sent to
          </p>
          <input
            type="email"
            placeholder={emailPlaceholder}
            className="styled-input"
            onFocus={() => setEmailPlaceholder("")}
            onBlur={() => setEmailPlaceholder("Enter email address")}
          />
          <div className="resetpass-actions">
            <button
              type="submit"
              className="reset-btn"
              onClick={handleResetRequest}
            >
              Request reset link
            </button>
            <button
              type="button"
              className="cancel-btn"
              onClick={handleCancel} // Call handleCancel to go back to login
            >
              Cancel
            </button>
          </div>
        </form>
      </div>

      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-content">
            <div className="popup-icon">
              <span>✔</span> {/* Checkmark icon */}
            </div>
            <h2>Done</h2>
            <p>An email with password reset instruction has been sent to your email address</p>
            <button className="close-btn" onClick={handleClosePopup}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResetPass;
```

# src\components\register\Reg1.css

```css
.signup-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-overlay {
    position: relative;
    background-color: rgba(255, 255, 255, 0.75);
    padding: 30px;
    border-radius: 50px;
    text-align: center;
    max-width: 450px;
    max-height: 90%;
    width: 100%;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.signup-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 24px;
}

.signup-header-row {
    display: flex;
    align-items: center; 
    gap: 16px; 
    justify-content: center;
}

.signup-logo {
    width: 115px; 
    height: auto;
    margin-left: -50px;
}

.signup-header h1 {
    font-size: 1.3rem;
    font-weight: bold;
    color: #172D75;
    font-family: Inter, sans-serif;
    margin: 0; 
 
}

.signup-header p {
    font-size: 1rem;
    color: black;
    font-family: Inter, sans-serif;
    margin-top: 12px; 
}

.signup-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    width: 100%;
}

.back-btn, .start-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    color: white;
    transition: background-color 0.3s;
}

.back-btn {
    background-color: #172D75;
    margin-left: 90px;
}

.start-btn {
    background-color: #172D75;
    margin-right: 90px;
}

.back-btn:hover, .start-btn:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .signup-overlay {
        padding: 15px;
        max-height: 85%;
    }

    .signup-header h1 {
        font-size: 1.2rem;
    }

    .signup-header p {
        font-size: 0.9rem;
    }

    .signup-header-row {
        gap: 8px; 
    }

    .back-btn, .start-btn {
        font-size: 14px;
        padding: 10px;
    }
}

@media (max-width: 480px) {
    .signup-overlay {
        padding: 10px;
        border-radius: 30px;
    }

    .signup-header h1 {
        font-size: 1rem;
    }

    .signup-header p {
        font-size: 0.8rem;
    }

    .signup-header-row {
        gap: 4px; 
    }

    .back-btn, .start-btn {
        font-size: 12px;
        padding: 8px;
    }
}

```

# src\components\register\Reg1.jsx

```jsx
import React from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "./Reg1.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png";

const Reg1 = () => {
  const navigate = useNavigate(); // Get the navigate function

  const handleStartNow = () => {
    navigate("/registration-details");
  };

  const handleGoBack = () => {
    navigate(-1); // Go back one step in the history
  };

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-header">
          <div className="signup-header-row">
            <img src={logo} alt="Blue Logo" className="signup-logo" />
            <h1>Alumni Sign up Form</h1>
          </div>
          <p>This form aims to gather current information from our Alumnus/Alumna.</p>
        </div>
        <div className="signup-actions">
          <button className="back-btn" onClick={handleGoBack}>Back</button> {/* Call handleGoBack on click */}
          <button className="start-btn" onClick={handleStartNow}>Start Now</button>
        </div>
      </div>
    </div>
  );
};

export default Reg1;
```

# src\components\register\Reg2.css

```css
.signup-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-overlay {
  position: relative;
  background-color: rgba(255, 255, 255, 0.75);
  padding: 30px;
  border-radius: 50px;
  text-align: left;
  max-width: 450px;
  width: 100%;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

.signup-content {
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 90vh;
  scrollbar-width: thin;
  scrollbar-color: #393d46 rgba(200, 200, 200, 0.5);
}

.signup-content::-webkit-scrollbar {
  width: 8px;
}

.signup-content::-webkit-scrollbar-thumb {
  background: #393d46;
  border-radius: 10px;
}

.signup-content::-webkit-scrollbar-thumb:hover {
  background: #2c2f34;
}

.signup-content::-webkit-scrollbar-track {
  background: rgba(200, 200, 200, 0.5);
  border-radius: 10px;
}

.signup-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 24px;
}

.signup-header-row {
    display: flex;
    align-items: center;
    gap: 16px;
    justify-content: center;
}

.signup-logo {
    width: 115px;
    height: auto;
    margin-right: 10px;
}

.signup-header h1 {
    font-size: 1.3rem;
    font-weight: bold;
    color: #172D75;
    font-family: Inter, sans-serif;
    margin: 0;
    margin-right: 50px;
   
}

.signup-form {
    text-align: left;
    margin-bottom: 16px;
    display: flex;
    flex-direction: column;
    gap: 24px;
    font-family: 'Inter', sans-serif;
}

.signup-form label {
    font-size: 0.9rem;
    color: black;
    font-family: Inter, sans-serif;
    margin-bottom: 8px;
    display: block;
}

.signup-form input[type="text"],
.signup-form select {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
    background-color: rgba(255, 255, 255, 0.7);
    transition: border-color 0.3s, background-color 0.3s;
    box-sizing: border-box;
    margin-bottom: 16px;
}

.signup-form input[type="text"]:focus,
.signup-form select:focus {
    border-color: rgba(0, 86, 179, 0.7);
    background-color: rgba(255, 255, 255, 0.10);
}

.checkbox-group label {
    display: block;
    font-size: 0.9rem;
    margin-bottom: 8px;
}

.signup-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    width: 100%;
}

.back-btn, .next-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    color: white;
    transition: background-color 0.3s;
}

.back-btn {
    background-color: #172D75;
}

.next-btn {
    background-color: #172D75;
    margin-right: 110px;
}

.back-btn:hover, .next-btn:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .signup-overlay {
        padding: 15px;
        max-height: 85%;
    }

    .signup-header h1 {
        font-size: 1.2rem;
    }

    .signup-form label {
        font-size: 0.8rem;
    }

    .signup-form input[type="text"],
    .signup-form select {
        font-size: 0.9rem;
    }

    .back-btn, .next-btn {
        font-size: 14px;
        padding: 10px;
    }
}

@media (max-width: 480px) {
    .signup-overlay {
        padding: 10px;
        border-radius: 30px;
    }

    .signup-header h1 {
        font-size: 1rem;
    }

    .signup-form label {
        font-size: 0.7rem;
    }

    .signup-form input[type="text"],
    .signup-form select {
        font-size: 0.8rem;
    }

    .back-btn, .next-btn {
        font-size: 12px;
        padding: 8px;
    }
}

.next-btn:disabled {
    background-color: #ccc;
    cursor: not-allowed;
    color: rgba(255, 255, 255, 0.6);
}
```

# src\components\register\Reg2.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg2.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg2 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    program: "",
    yearGraduated: "",
    educationLevel: [],
  });

  const handleBack = () => {
    navigate("/alumni-signup");
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    setFormData((prevState) => {
      const updatedLevels = checked
        ? [...prevState.educationLevel, value]
        : prevState.educationLevel.filter((level) => level !== value);
      return { ...prevState, educationLevel: updatedLevels };
    });
  };

  const isFormComplete =
    formData.fullName.trim() &&
    formData.program.trim() &&
    formData.yearGraduated.trim() &&
    formData.educationLevel.length > 0;

  const handleNext = () => {
    if (isFormComplete) {
      navigate("/additional-details"); 
    }
  };

  return (
    <div
      className="signup-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>1. Full Name (First Name, Middle Name, Last Name)</label>
            <input
              type="text"
              name="fullName"
              value={formData.fullName}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>2. Program/Course</label>
            <input
              type="text"
              name="program"
              value={formData.program}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>3. Year Graduated (e.g., May 2018)</label>
            <input
              type="text"
              name="yearGraduated"
              value={formData.yearGraduated}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>4. Educational level completed</label>
            <div className="checkbox-group">
              <label>
                <input
                  type="checkbox"
                  value="Elementary"
                  onChange={handleCheckboxChange}
                  checked={formData.educationLevel.includes("Elementary")}
                />
                Elementary
              </label>
              <label>
                <input
                  type="checkbox"
                  value="High School"
                  onChange={handleCheckboxChange}
                  checked={formData.educationLevel.includes("High School")}
                />
                High School
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Associate's Degree"
                  onChange={handleCheckboxChange}
                  checked={formData.educationLevel.includes("Associate's Degree")}
                />
                Associate's Degree
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Bachelor's Degree"
                  onChange={handleCheckboxChange}
                  checked={formData.educationLevel.includes("Bachelor's Degree")}
                />
                Bachelor's Degree
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Master's Degree"
                  onChange={handleCheckboxChange}
                  checked={formData.educationLevel.includes("Master's Degree")}
                />
                Master's Degree
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Doctor's Degree"
                  onChange={handleCheckboxChange}
                  checked={formData.educationLevel.includes("Doctor's Degree")}
                />
                Doctor's Degree
              </label>
            </div>
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleNext}
                disabled={!isFormComplete} 
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg2;
```

# src\components\register\Reg3.css

```css
.signup-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-overlay {
    position: relative;
    background-color: rgba(255, 255, 255, 0.75);
    padding: 30px;
    border-radius: 50px;
    text-align: center;
    max-width: 450px;
    max-height: 90%;
    width: 100%;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
}

.signup-content {
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 90vh;
  scrollbar-width: thin;
  scrollbar-color: #393d46 rgba(200, 200, 200, 0.5);
}

.signup-content::-webkit-scrollbar {
  width: 8px;
}

.signup-content::-webkit-scrollbar-thumb {
  background: #393d46;
  border-radius: 10px;
}

.signup-content::-webkit-scrollbar-thumb:hover {
  background: #2c2f34;
}

.signup-content::-webkit-scrollbar-track {
  background: rgba(200, 200, 200, 0.5);
  border-radius: 10px;
}

.signup-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 24px;
}

.signup-header-row {
    display: flex;
    align-items: center;
    gap: 16px;
    justify-content: center;
}

.signup-logo {
    width: 115px;
    height: auto;
    margin-right: 10px;
}

.signup-header h1 {
    font-size: 1.3rem;
    font-weight: bold;
    color: #172D75;
    font-family: Inter, sans-serif;
    margin: 0;
    margin-right: 50px;
}

.signup-form {
  text-align: left;
  margin-bottom: 16px;
  display: flex;
  flex-direction: column;
  gap: 24px;
  font-family: 'Inter', sans-serif;
}

.signup-form label {
    font-size: 0.9rem;
    color: black;
    font-family: Inter, sans-serif;
    margin-bottom: 8px;
    display: block;
}

.signup-form input[type="text"],
.signup-form select {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
    background-color: rgba(255, 255, 255, 0.7);
    transition: border-color 0.3s, background-color 0.3s;
    box-sizing: border-box;
    margin-bottom: 16px;
}

.signup-form input[type="radio"],
.signup-form input[type="checkbox"] {
    margin-right: 8px;
    margin-top: 6px;
}

.signup-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    width: 100%;
}

.back-btn, .next-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    color: white;
    transition: background-color 0.3s;
}

.back-btn {
    background-color: #172D75;
}

.next-btn {
    background-color: #172D75;
    margin-right: 110px;
}

.back-btn:hover, .next-btn:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .signup-overlay {
        padding: 15px;
        max-height: 85%;
    }

    .signup-header h1 {
        font-size: 1.2rem;
    }

    .signup-form label {
        font-size: 0.8rem;
    }

    .signup-form input[type="text"],
    .signup-form select {
        font-size: 0.9rem;
    }

    .back-btn, .next-btn {
        font-size: 14px;
        padding: 10px;
    }
}

@media (max-width: 480px) {
    .signup-overlay {
        padding: 10px;
        border-radius: 30px;
    }

    .signup-header h1 {
        font-size: 1rem;
    }

    .signup-form label {
        font-size: 0.7rem;
    }

    .signup-form input[type="text"],
    .signup-form select {
        font-size: 0.8rem;
    }

    .back-btn, .next-btn {
        font-size: 12px;
        padding: 8px;
    }
}

.next-btn:disabled {
    background-color: #ccc;
    cursor: not-allowed;
    color: rgba(255, 255, 255, 0.6);
}
```

# src\components\register\Reg3.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg3.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg3 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    age: "",
    sexAtBirth: "",
    contactNumber: "",
    emailAddress: "",
    currentAddress: "",
  });
  const [error, setError] = useState(""); // State for error message

  const handleBack = () => {
    navigate("/registration-details");
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
    setError(""); // Clear the error message on input change
  };

  const isFormComplete =
    formData.age.trim() &&
    formData.sexAtBirth &&
    formData.contactNumber.trim() &&
    formData.emailAddress.trim() &&
    formData.currentAddress.trim();

  const handleNext = () => {
    // Check if email ends with @gmail.com
    if (!formData.emailAddress.endsWith("@gmail.com")) {
      setError("Email address must end with '@gmail.com'.");
      return;
    }

    // Navigate to the next page if everything is valid
    if (isFormComplete) {
      navigate("/final-details");
    }
  };

  return (
    <div
      className="signup-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>5. Age</label>
            <input
              type="text"
              name="age"
              value={formData.age}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>6. Sex at birth</label>
            <div>
              <label>
                <input
                  type="radio"
                  name="sexAtBirth"
                  value="Female"
                  onChange={handleInputChange}
                  checked={formData.sexAtBirth === "Female"}
                />
                Female
              </label>
              <label>
                <input
                  type="radio"
                  name="sexAtBirth"
                  value="Male"
                  onChange={handleInputChange}
                  checked={formData.sexAtBirth === "Male"}
                />
                Male
              </label>
            </div>

            <label>7. Contact Number (Mobile)</label>
            <input
              type="text"
              name="contactNumber"
              value={formData.contactNumber}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>8. Personal Email Address</label>
            <input
              type="text"
              name="emailAddress"
              value={formData.emailAddress}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />
            {error && <p className="error-message">{error}</p>}

            <label>9. Current Address</label>
            <input
              type="text"
              name="currentAddress"
              value={formData.currentAddress}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleNext}
                disabled={!isFormComplete}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg3;
```

# src\components\register\Reg4.css

```css
.signup-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-overlay {
    position: relative;
    background-color: rgba(255, 255, 255, 0.75);
    padding: 30px;
    border-radius: 50px;
    text-align: center;
    max-width: 450px;
    max-height: 90%;
    width: 100%;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
}

.signup-content {
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 90vh;
  scrollbar-width: thin;
  scrollbar-color: #393d46 rgba(200, 200, 200, 0.5);
}

.signup-content::-webkit-scrollbar {
  width: 8px;
}

.signup-content::-webkit-scrollbar-thumb {
  background: #393d46;
  border-radius: 10px;
}

.signup-content::-webkit-scrollbar-thumb:hover {
  background: #2c2f34;
}

.signup-content::-webkit-scrollbar-track {
  background: rgba(200, 200, 200, 0.5);
  border-radius: 10px;
}

.signup-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 24px;
}

.signup-header-row {
    display: flex;
    align-items: center;
    gap: 16px;
    justify-content: center;
}

.signup-logo {
    width: 115px;
    height: auto;
    margin-right: 10px;
}

.signup-header h1 {
    font-size: 1.3rem;
    font-weight: bold;
    color: #172D75;
    font-family: Inter, sans-serif;
    margin: 0;
    margin-right: 50px;
}

.signup-form {
  text-align: left;
  margin-bottom: 16px;
  display: flex;
  flex-direction: column;
  gap: 24px;
  font-family: 'Inter', sans-serif;
}

.signup-form label {
    font-size: 0.9rem;
    color: black;
    font-family: Inter, sans-serif;
    margin-bottom: 8px; 
    display: block;
}

.signup-form input[type="text"],
.signup-form select {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
    background-color: rgba(255, 255, 255, 0.7);
    transition: border-color 0.3s, background-color 0.3s;
    box-sizing: border-box;
    margin-bottom: 16px;
}

.signup-form input[type="radio"],
.signup-form input[type="checkbox"] {
    margin-right: 8px; 
    margin-top: 6px;  
}

.signup-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    width: 100%;
}

.back-btn, .next-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    color: white;
    transition: background-color 0.3s;
}

.back-btn {
    background-color: #172D75;
}

.next-btn {
    background-color: #172D75;
    margin-right: 110px;
}

.back-btn:hover, .next-btn:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .signup-overlay {
        padding: 15px;
        max-height: 85%;
    }

    .signup-header h1 {
        font-size: 1.2rem;
    }

    .signup-form label {
        font-size: 0.8rem;
    }

    .signup-form input[type="text"],
    .signup-form select {
        font-size: 0.9rem;
    }

    .back-btn, .next-btn {
        font-size: 14px;
        padding: 10px;
    }
}

@media (max-width: 480px) {
    .signup-overlay {
        padding: 10px;
        border-radius: 30px;
    }

    .signup-header h1 {
        font-size: 1rem;
    }

    .signup-form label {
        font-size: 0.7rem;
    }

    .signup-form input[type="text"],
    .signup-form select {
        font-size: 0.8rem;
    }

    .back-btn, .next-btn {
        font-size: 12px;
        padding: 8px;
    }
}

.next-btn:disabled {
    background-color: #ccc;
    cursor: not-allowed;
    color: rgba(255, 255, 255, 0.6);
}
```

# src\components\register\Reg4.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg4.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg4 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    citizenship: "",
    presentWork: "",
    position: "",
    alumniActivities: [],
    otherActivity: "",
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    if (checked) {
      setFormData({
        ...formData,
        alumniActivities: [...formData.alumniActivities, name],
      });
    } else {
      setFormData({
        ...formData,
        alumniActivities: formData.alumniActivities.filter(
          (activity) => activity !== name
        ),
      });
    }
  };

  const handleBack = () => {
    navigate("/additional-details");
  };

  const handleSubmit = () => {
    navigate("/social-links"); 
  };

  const isFormComplete =
    formData.citizenship.trim() &&
    formData.presentWork.trim() &&
    formData.position.trim();

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>10. Citizenship</label>
            <input
              type="text"
              name="citizenship"
              value={formData.citizenship}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>11. Present Work / Company</label>
            <input
              type="text"
              name="presentWork"
              value={formData.presentWork}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>12. Position (Title)</label>
            <input
              type="text"
              name="position"
              value={formData.position}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>13. Alumni activities I would like to get notified</label>
            <div>
              <label>
                <input
                  type="checkbox"
                  name="Alumni Reunions"
                  onChange={handleCheckboxChange}
                />
                Alumni Reunions
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Volunteer Programs"
                  onChange={handleCheckboxChange}
                />
                Volunteer Programs
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Interest Groups"
                  onChange={handleCheckboxChange}
                />
                Interest Groups (e.g., Auto Club, Biker's Club, Golf Club, Entrepreneurs Club)
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Mentoring Programs"
                  onChange={handleCheckboxChange}
                />
                Mentoring Programs (e.g., Talks, Featured Alumni, Guest Speakers)
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Partnerships and Sponsorships"
                  onChange={handleCheckboxChange}
                />
                Partnerships and Sponsorships
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Career Fairs"
                  onChange={handleCheckboxChange}
                />
                Career Fairs
              </label>
              <label>
                <input
                  type="checkbox"
                  name="Other"
                  onChange={handleCheckboxChange}
                />
                Other
              </label>
              {formData.alumniActivities.includes("Other") && (
                <input
                  type="text"
                  name="otherActivity"
                  value={formData.otherActivity}
                  placeholder="Specify other activity"
                  onChange={handleInputChange}
                />
              )}
            </div>
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleSubmit}
                disabled={!isFormComplete}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg4;
```

# src\components\register\Reg5.css

```css
.signup-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-overlay {
    position: relative;
    background-color: rgba(255, 255, 255, 0.75);
    padding: 30px;
    border-radius: 50px;
    text-align: center;
    max-width: 450px;
    max-height: 90%;
    width: 100%;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.signup-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 24px;
}

.signup-header-row {
    display: flex;
    align-items: center;
    gap: 16px;
    justify-content: center;
}

.signup-logo {
    width: 115px;
    height: auto;
    margin-right: 10px;
}

.signup-header h1 {
    font-size: 1.3rem;
    font-weight: bold;
    color: #172D75;
    font-family: Inter, sans-serif;
    margin: 0;
    margin-right: 50px;
}

.signup-form {
    text-align: left;
    margin-bottom: 16px;
}

.signup-form label {
    font-size: 0.9rem;
    color: black;
    font-family: Inter, sans-serif;
    margin-bottom: 8px;
    display: block;
    margin-top: 20px;
}

.signup-form input[type="text"],
.signup-form input[type="password"] {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
    background-color: rgba(255, 255, 255, 0.7);
    transition: border-color 0.3s, background-color 0.3s;
    box-sizing: border-box;
    margin-bottom: 16px;
}

.signup-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    width: 100%;
}

.back-btn, .next-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    color: white;
    transition: background-color 0.3s;
}

.back-btn {
    background-color: #172D75;
}

.next-btn {
    background-color: #172D75;
    margin-right: 110px;
}

.back-btn:hover, .next-btn:hover {
    background-color: #0056b3;
}

.next-btn:disabled {
    background-color: #ccc;
    cursor: not-allowed;
    color: rgba(255, 255, 255, 0.6);
}

```

# src\components\register\Reg5.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg5.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg5 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    linkedIn: "",
    facebook: "",
    instagram: "",
    password: "",
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleBack = () => {
    navigate("/final-details");
  };

  const handleSubmit = () => {
    console.log("Form data submitted:", formData);
    navigate("/review-form"); 
  };

  const isFormComplete =
    formData.linkedIn.trim() &&
    formData.facebook.trim() &&
    formData.instagram.trim() &&
    formData.password.trim();

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>13. LinkedIn Profile Link/Name</label>
            <input
              type="text"
              name="linkedIn"
              value={formData.linkedIn}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>14. Facebook Profile Link/Name</label>
            <input
              type="text"
              name="facebook"
              value={formData.facebook}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>15. Instagram Profile Link/Name</label>
            <input
              type="text"
              name="instagram"
              value={formData.instagram}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>16. Set up your password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              placeholder="Enter your password"
              onChange={handleInputChange}
            />
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleSubmit}
                disabled={!isFormComplete}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg5;
```

# src\components\register\Reg6.css

```css
.signup-container {
    height: 100vh;
    width: 100vw;
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-overlay {
    position: relative;
    background-color: rgba(255, 255, 255, 0.75);
    padding: 30px;
    border-radius: 50px;
    text-align: center;
    max-width: 450px;
    max-height: 90%;
    width: 100%;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.signup-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 24px;
}

.signup-header-row {
    display: flex;
    align-items: center;
    gap: 16px;
    justify-content: center;
}

.signup-logo {
    width: 115px;
    height: auto;
    margin-right: 10px;
}

.signup-header h1 {
    font-size: 1.3rem;
    font-weight: bold;
    color: #172D75;
    font-family: Inter, sans-serif;
    margin: 0;
}

.signup-form {
    text-align: left;
    margin-bottom: 16px;
    font-size: 0.9rem;
    color: black;
    font-family: Inter, sans-serif;
}

.signup-checkbox {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 20px;
}

.signup-checkbox input[type="checkbox"] {
    transform: scale(1.2);
    margin-top: 15px;
}

.signup-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    width: 100%;
}

.back-btn, .submit-btn {
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: none;
    border-radius: 8px;
    color: white;
    transition: background-color 0.3s;
}

.back-btn {
    background-color: #172D75;
}

.next-btn {
    background-color: #172D75;
    margin-right: 110px;
}

.back-btn:hover, .submit-btn:hover {
    background-color: #0056b3;
}

```

# src\components\register\Reg6.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg6.css";
import background from "../../assets-register/Background.jpeg";
import logo from "../../assets-register/Blue Logo.png"; // Or backLogo.png if used

const Reg6 = () => {
  const navigate = useNavigate();
  const [isChecked, setIsChecked] = useState(false);

  const handleBack = () => {
    navigate("/social-links");
  };

  const handleSubmit = () => {
    if (isChecked) {
      console.log("Form submitted");
      navigate("/verify-account"); 
    }
  };

  const handleCheckboxChange = (e) => {
    setIsChecked(e.target.checked); 
  };

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-header">
          <div className="signup-header-row">
            <img src={logo} alt="Blue Logo" className="signup-logo" />
            <h1>Alumni Sign up Form</h1>
          </div>
        </div>
        <div className="signup-form">
          <p>
            I hereby agree, that I permit the NU Alumni Affairs Office-Manila to share my email address
            (only) to my respective college program (i.e., College of Business and Accountancy, College of Architecture).
            This aims to receive updates from respective colleges regarding upcoming activities.
          </p>
          <p>
            I hereby agree that the above information is true and correct to the best of my knowledge. 
            I hereby authorize the NU Alumni Affairs Office to connect with me through the details indicated 
            above for upcoming events, promotions, and updates regarding my Alma Mater, the National University.
          </p>
          <div className="signup-checkbox">
            <input
              type="checkbox"
              id="agree"
              name="agree"
              onChange={handleCheckboxChange} 
            />
            <label htmlFor="agree">I agree.</label>
          </div>
        </div>
        <div className="signup-actions">
          <button className="back-btn" onClick={handleBack}>
            Back
          </button>
          <button
            className="next-btn"
            onClick={handleSubmit}
            disabled={!isChecked} 
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reg6;

```

# src\components\register\Reg7.css

```css
.reg7-container {
  height: 100vh;
  width: 100vw;
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
}

.reg7-overlay {
  background: rgba(255, 255, 255, 0.85);
  width: 350px;
  padding: 40px;
  border-radius: 50px;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
  text-align: center;
  max-height: 85%;
  overflow-y: auto;
}

.reg7-header h1 {
  margin-bottom: 20px;
  font-size: 1.5rem;
  font-weight: bold;
  font-family: Inter, sans-serif;
  color: #172d75;
  text-shadow: 
    -1px -1px 0 #fff, 
    1px -1px 0 #fff,  
    -1px 1px 0 #fff,  
    1px 1px 0 #fff;
}

.reg7-content p {
  margin-bottom: 15px;
  font-size: 0.9rem;
  color: #444;
  font-family: Inter, sans-serif;
}

.reg7-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.reg7-input {
  padding: 12px;
  font-size: 20px;
  text-align: center;
  letter-spacing: 10px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.1);
  transition: border-color 0.3s, background-color 0.3s;
}

.reg7-input:focus {
  border-color: rgba(0, 86, 179, 0.7);
  background-color: rgba(255, 255, 255, 0.1);
  outline: none;
}

.reg7-note {
  font-size: 0.8rem;
  color: #635858;
  font-family: Inter, sans-serif;
  margin-top: -10px;
  text-align: left;
}

.reg7-note a {
  text-decoration: none;
  font-weight: bold;
  color: #5990d7;
  text-shadow: 
      -1px -1px 0 #fff, 
      1px -1px 0 #fff,  
      -1px 1px 0 #fff,  
      1px 1px 0 #fff;
}

.reg7-note a:hover {
  text-decoration: underline;
}

.reg7-buttons {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-top: 20px;
}

.reg7-btn {
  padding: 12px 20px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  border: none;
  border-radius: 8px;
  background-color: #172d75;
  color: white;
  transition: background-color 0.3s;
}

.reg7-btn:hover {
  background-color: #0056b3;
}

.popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 300px;
  padding: 20px;
  background: white;
  border: 1px solid #ccc;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-align: center;
  z-index: 1000;
}

.popup p {
  font-size: 1rem;
  color: #444;
  margin-bottom: 20px;
  font-family: Inter, sans-serif;
}

.popup-btn {
  padding: 10px 15px;
  font-size: 14px;
  font-weight: bold;
  color: white;
  background-color: #172d75;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}

.popup-btn:hover {
  background-color: #0056b3;
}

.welcome-popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 300px;
  padding: 20px;
  background: white;
  border: 1px solid #ccc;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-align: center;
  z-index: 1000;
}

.welcome-popup p {
  font-size: 1rem;
  color: #444;
  margin-bottom: 20px;
  font-family: Inter, sans-serif;
  margin-top: 25px;
}

.welcome-popup h2 {
  font-size: 1.5rem;
  color: black;
  margin-bottom: 10px;
  font-family: Inter, sans-serif;
}

.welcome-btn {
  padding: 10px 15px;
  font-size: 14px;
  font-weight: bold;
  color: white;
  background-color: #172d75;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  margin-top: 5px;
}

.welcome-btn:hover {
  background-color: #0056b3;
}

@media (max-width: 768px) {
  .reg7-overlay {
    width: 90%;
    padding: 20px;
  }

  .reg7-input {
    font-size: 14px;
    padding: 8px;
  }

  .reg7-btn, .cancel-btn {
    font-size: 14px;
    padding: 10px;
  }
}

@media (max-width: 480px) {
  .reg7-overlay {
    border-radius: 30px;
  }

  .reg7-input {
    font-size: 12px;
  }

  .reg7-btn, .cancel-btn {
    padding: 8px;
  }
}

```

# src\components\register\Reg7.jsx

```jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg7.css";
import background from "../../assets-register/Background.jpeg";


const Reg7 = () => {
  const [verificationCode, setVerificationCode] = useState("");
  const [isResendPopupVisible, setIsResendPopupVisible] = useState(false);
  const [isWelcomePopupVisible, setIsWelcomePopupVisible] = useState(false);
  const navigate = useNavigate();

  const handleBackClick = () => {
    navigate("/review-form");
  };

  const handleChange = (e) => {
    setVerificationCode(e.target.value);
  };

  const handleResend = () => {
    setIsResendPopupVisible(true);
    setTimeout(() => setIsResendPopupVisible(false), 3000);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsWelcomePopupVisible(true);
  };

  const closeWelcomePopup = () => {
    setIsWelcomePopupVisible(false);
    navigate("/dashboard");
  };

  return (
    <div
      className="reg7-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="reg7-overlay">
        <div className="reg7-header">
          <h1>Verify Your Account</h1>
        </div>
        <div className="reg7-content">
          <p>
            Please enter the 6-digits verification code sent to your email to
            complete registration.
          </p>
          <form className="reg7-form" onSubmit={handleSubmit}>
            <input
              type="text"
              maxLength="6"
              placeholder="______"
              value={verificationCode}
              onChange={handleChange}
              className="reg7-input"
            />
            <p className="reg7-note">
              Note: This code is only valid for 10 minutes. If you didn’t
              receive a code, please check your spam folder or{" "}
              <a href="#resend" onClick={handleResend}>
                Resend
              </a>.
            </p>
            <div className="reg7-buttons">
              <button type="button" className="reg7-btn" onClick={handleBackClick}>
                Back
              </button>
              <button type="submit" className="reg7-btn">
                Done
              </button>
            </div>
          </form>
        </div>
      </div>
      {isResendPopupVisible && (
        <div className="popup">
          <p>
            A new verification code has been sent to your email. Please check
            your inbox and enter the code.
          </p>
          <button
            className="popup-btn"
            onClick={() => setIsResendPopupVisible(false)}
          >
            Close
          </button>
        </div>
      )}
      {isWelcomePopupVisible && (
        <div className="welcome-popup">
          <h2>Welcome to CCIT Alumni Connect!</h2>
          <p>To complete your account setup, please click Done to continue.</p>
          <button className="welcome-btn" onClick={closeWelcomePopup}>
            Done
          </button>
        </div>
      )}
    </div>
  );
};

export default Reg7;

```

# src\index.css

```css
index.css

body {
  font-family: Inter;
  margin: 0;
  padding: 0;
  color: #666666;
  background-color: #f9f9f9;
}

@media (max-width: 768px) {
  body {
    font-size: 14px; 
  }
}

@media (max-width: 480px) {
  body {
    font-size: 12px; 
  }
}
```

# src\main.jsx

```jsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import "./index.css";

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

```

# vite.config.js

```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
})

```

