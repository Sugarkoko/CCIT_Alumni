import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import "./Authentication.css";
import background from '../../assets-login/BackgroundCover.jpeg';

const Authentication = () => {
  const [verificationCode, setVerificationCode] = useState("");
  const [isPopupVisible, setIsPopupVisible] = useState(false); 
  const navigate = useNavigate(); 

  const handleBackClick = () => {
    navigate("/login"); 
  };

  const handleChange = (e) => {
    setVerificationCode(e.target.value);
  };

  const handleResend = () => {
    setIsPopupVisible(true); 
    setTimeout(() => setIsPopupVisible(false), 3000); 
  };

  return (
    <div
      className="auth-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="auth-overlay">
        <div className="auth-header">
          <h1>Enter Your 6-Digits Verification Code</h1>
        </div>
        <div className="auth-content">
          <p>
            For added security, we’ve sent a 6-digits verification code to your
            email.
          </p>
          <p>
            Please enter the code below to confirm your identity and continue
            accessing your account.
          </p>
          <form className="auth-form">
            <input
              type="text"
              maxLength="6"
              placeholder="______"
              value={verificationCode}
              onChange={handleChange}
              className="auth-input"
            />
            <p className="auth-note">
              Note: This code is only valid for 10 minutes. If you didn’t
              receive a code, please check your spam folder or request a new
              one. <a href="#resend" onClick={handleResend}>Resend</a>
            </p>
            <div className="auth-buttons">
              <button
                type="button"
                className="auth-btn back-btn"
                onClick={handleBackClick}
              >
                Back
              </button>
              <button type="submit" className="auth-btn">
                Done
              </button>
            </div>
          </form>
        </div>
      </div>
      {isPopupVisible && (
        <div className="popup">
          <p>
            A new verification code has been sent to your email. Please check
            your inbox and enter the code.
          </p>
          <button
            className="popup-btn"
            onClick={() => setIsPopupVisible(false)}
          >
            Done
          </button>
        </div>
      )}
    </div>
  );
};

export default Authentication;
