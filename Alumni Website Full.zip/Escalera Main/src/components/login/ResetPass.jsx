import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import "./ResetPass.css";
import background from '../../assets-login/BackgroundCover.jpeg';
import logo from "../../assets-login/Blue Logo.png";

const ResetPass = () => {
  const [emailPlaceholder, setEmailPlaceholder] = useState("Enter email address");
  const [showPopup, setShowPopup] = useState(false); 
  const navigate = useNavigate();

  const handleResetRequest = (e) => {
    e.preventDefault();
    setShowPopup(true); 
  };

  const handleClosePopup = () => {
    setShowPopup(false); 
    navigate("/"); 
  };

  return (
    <div
      className="resetpass-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="resetpass-overlay">
        <div className="resetpass-header">
          <img src={logo} alt="Logo" className="resetpass-logo" />
          <h1>Reset your password</h1>
        </div>
        <form className="resetpass-form">
          <p>
            Please enter the email address you'd like your password reset
            information sent to
          </p>
          <input
            type="email"
            placeholder={emailPlaceholder}
            className="styled-input"
            onFocus={() => setEmailPlaceholder("")}
            onBlur={() => setEmailPlaceholder("Enter email address")}
          />
          <div className="resetpass-actions">
            <button
              type="submit"
              className="reset-btn"
              onClick={handleResetRequest}
            >
              Request reset link
            </button>
            <button
              type="button"
              className="cancel-btn"
              onClick={() => navigate("/")}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>

      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-content">
            <div className="popup-icon">
              <span>&#10004;</span> {/* Checkmark icon */}
            </div>
            <h2>Done</h2>
            <p>An email with password reset instruction has been sent to your email address</p>
            <button className="close-btn" onClick={handleClosePopup}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResetPass;
