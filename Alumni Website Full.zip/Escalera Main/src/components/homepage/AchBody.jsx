import React, { useState, useEffect } from 'react';
import enyuWebp from "../../assets-homepage/enyu.webp";
import enyu1Jpg from '../../assets-homepage/enyu1.jpg';
import enyu2Jpg from '../../assets-homepage/enyu2.jpg';
import acadsPng from '../../assets-homepage/acads.png';
import sportsPng from '../../assets-homepage/sports.png';
import trophyPng from '../../assets-homepage/trophy.png';
import './AchBody.css';

function AchBody() {
  const images = [enyuWebp, enyu1Jpg, enyu2Jpg];
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const autoSlide = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3000); 
    return () => clearInterval(autoSlide); 
  }, [images.length]);

  return (
    <main className="achievements-frame">
      <div className="achievements-header">
        <img
          src={images[currentIndex]}
          alt="National University"
          className="header-image"
        />
        <h1>National University</h1>
      </div>
      <section className="achievements-content">
        <div className="achievements-container">
          <div className="achievement-card">
          <img src={acadsPng} alt="Academic Icon" />
            <p>
              National University (NU), established on August 1, 1900, recently
              celebrated its 122nd founding anniversary, marking over a century
              of academic excellence and dedicated educational service.
            </p>
          </div>
          <div className="achievement-card">
          <img src={sportsPng} alt="Sports Icon" />
            <p>
              As a founding member of the University Athletic Association of
              the Philippines (UAAP), NU’s varsity teams, known as the Bulldogs,
              have consistently excelled in various sports.
            </p>
          </div>
          <div className="achievement-card">
          <img src={trophyPng} alt="Award Icon" />
            <p>
              National University (NU) Manila has been recognized for its
              dedication to academic equity and excellence, receiving four
              prestigious awards from PACUCOA.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}

export default AchBody;