import React from 'react';
import { Link } from 'react-router-dom'; // Make sure Link is imported
import nuBackgroundPng from '../../assets-homepage/nu-background.png';
import './Body.css';

const Body = () => {
  return (
    <div>
    <main className="body" style={{ backgroundImage: `url(${nuBackgroundPng})` }}> {/* Use imported image in style */}
      <section className="content">
        <h2>Welcome to National University Alumni Portal</h2>
        <p>Join us and stay connected with the CCIT alumni community.</p>
        <div className="buttons">
          <button className="join-btn">Join Now!</button>
          <Link to="/login" className="login-btn">Login</Link> {/* Link component for Login button */}
        </div>
      </section>
    </main>
    </div>
  );
};

export default Body;