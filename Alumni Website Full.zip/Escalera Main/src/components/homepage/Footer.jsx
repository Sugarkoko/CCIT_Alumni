import React from 'react';
import './Footer.css'

function Footer() {
    return (
        <footer className="footer">
          <div className="footer-section">
            <p>&copy;{new Date().getFullYear()} CCIT Alumni Connect. All rights reserved.</p>
            <p>Privacy Policy</p>
          </div>
          <div className="footer-section">
            <p>College of Computing and Information Technologies</p>
            <p>📞 +632 8712-1900</p>
          </div>
          <div className="footer-section">
            <p>Alumni Affairs</p>
            <p>📞 +632 8563-6991</p>
            <p><a href="mailto:alumni-affairs@national-u.edu.ph">📧 alumni-affairs@national-u.edu.ph</a></p>
          </div>
        </footer>
      );
    };
    
    export default Footer;