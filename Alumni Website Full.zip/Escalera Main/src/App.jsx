import React from 'react';
import Header from './components/homepage/Header';
import Body from './components/homepage/Body';
import EventsBody from './components/homepage/EventsBody';
import Footer from './components/homepage/Footer';
import AchBody from './components/homepage/AchBody';
import AboutBody from './components/homepage/AboutBody';
import ContactBody from './components/homepage/ContactBody';
import LogIn from './components/login/LogIn';
import ResetPass from './components/login/ResetPass';
import Authentication from './components/login/Authentication';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <Routes>
          <Route path="/" element={<Body />} />
          <Route path="/events" element={<EventsBody />} />
          <Route path="/achievements" element={<AchBody />} />
          <Route path="/about" element={<AboutBody />} />
          <Route path="/contact" element={<ContactBody />} />
          <Route path="/login" element={<LogIn />} />
          <Route path="/reset-password" element={<ResetPass />} /> {/* Add ResetPass Route */}
          <Route path="/authentication" element={<Authentication />} /> {/* Add Authentication Route */}
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;