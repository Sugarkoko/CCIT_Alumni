import React, { useState } from 'react';
import './WD1.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD1 = ({ onBack, onNext }) => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [previousEmployment, setPreviousEmployment] = useState(null); 

  const handleOptionChange = (value) => {
    setSelectedOption(value);
  };

  const handlePreviousEmploymentChange = (value) => {
    setPreviousEmployment(value); 
  };

  return (
    <div className="wd1-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd1-overlay">
        <div className="wd1-content">
          <div className="wd1-header">
            <img src={logo} alt="Logo" className="wd1-logo" />
            <h1>Employment Data</h1>
          </div>
          <p>22. Current Employment Status *</p>
          <div className="wd1-options">
            <label>
              <input
                type="radio"
                name="employmentStatus"
                value="full-time"
                onChange={() => handleOptionChange('full-time')}
              />
              Employed Full Time
            </label>
            <label>
              <input
                type="radio"
                name="employmentStatus"
                value="part-time"
                onChange={() => handleOptionChange('part-time')}
              />
              Employed Part-Time/Contractual
            </label>
            <label>
              <input
                type="radio"
                name="employmentStatus"
                value="self-employed"
                onChange={() => handleOptionChange('self-employed')}
              />
              Self Employed/Entrepreneur
            </label>
            <label>
              <input
                type="radio"
                name="employmentStatus"
                value="unemployed-before"
                onChange={() => handleOptionChange('unemployed-before')}
              />
              Unemployed but held a job before
            </label>
            <label>
              <input
                type="radio"
                name="employmentStatus"
                value="never-employed"
                onChange={() => handleOptionChange('never-employed')}
              />
              Never been employed
            </label>
          </div>

          {selectedOption === 'self-employed' && (
            <div className="previous-employment-question">
              <p>23. Did you have any previous employment? *</p>
              <label>
                <input
                  type="radio"
                  name="previousEmployment"
                  value="yes"
                  onChange={() => handlePreviousEmploymentChange('yes')}
                />
                Yes
              </label>
              <label>
                <input
                  type="radio"
                  name="previousEmployment"
                  value="no"
                  onChange={() => handlePreviousEmploymentChange('no')}
                />
                No
              </label>
            </div>
          )}

          <div className="wd1-button-container">
            <button onClick={onBack}>Back</button>
            <button onClick={onNext} disabled={!selectedOption}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD1;
