import React, { useState } from 'react';
import './WD6.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD6 = ({ onBack, onNext }) => {
  const [answers, setAnswers] = useState({
    companyName: '',
    companyLocation: '',
    country: '',
    jobClassification: '',
    jobClassificationOther: '',
    salaryRange: '',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setAnswers((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const isNextDisabled =
    !answers.companyName ||
    !answers.companyLocation ||
    (answers.companyLocation === 'Abroad' && !answers.country) ||
    !answers.jobClassification ||
    (answers.jobClassification === 'Others' && !answers.jobClassificationOther) ||
    !answers.salaryRange;

  return (
    <div className="wd6-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd6-overlay">
        <div className="wd6-content">
          <div className="wd6-header">
            <img src={logo} alt="Logo" className="wd6-logo" />
            <h1>Employment Data</h1>
          </div>

          <p>30. Company or Institution Name of your first employment after graduation *</p>
          <input
            type="text"
            placeholder="Enter your answer"
            className="input-field"
            name="companyName"
            value={answers.companyName}
            onChange={handleInputChange}
          />

          <p>31. Company location of first job *</p>
          <div className="choice-container">
            <label>
              <input
                type="radio"
                name="companyLocation"
                value="Local"
                onChange={handleInputChange}
              />
              Local
            </label>
            <label>
              <input
                type="radio"
                name="companyLocation"
                value="Abroad"
                onChange={handleInputChange}
              />
              Abroad
            </label>
          </div>

          {answers.companyLocation === 'Abroad' && (
            <>
              <p>32. Country of first job *</p>
              <input
                type="text"
                placeholder="Enter your answer"
                className="input-field"
                name="country"
                value={answers.country}
                onChange={handleInputChange}
              />
            </>
          )}

          <p>33. Job Classification of your first work assignment after graduation *</p>
          <div className="choice-container">
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="Entry-Level"
                onChange={handleInputChange}
              />
              Entry-Level (e.g.: Staff Member, Representative, Associate)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="First-level Management"
                onChange={handleInputChange}
              />
              First-level Management (e.g.: Manager, Supervisor, Team Leader)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="Middle Management"
                onChange={handleInputChange}
              />
              Middle Management (e.g.: Director, Regional Manager, Adviser)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="Executive or Senior Management"
                onChange={handleInputChange}
              />
              Executive or Senior Management (e.g.: Chief Officers, Executive, Vice President, President)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="Others"
                onChange={handleInputChange}
              />
              Others
            </label>
            {answers.jobClassification === 'Others' && (
              <input
                type="text"
                placeholder="Please specify"
                className="input-field"
                name="jobClassificationOther"
                value={answers.jobClassificationOther}
                onChange={handleInputChange}
              />
            )}
          </div>

          <p>34. Salary Range *</p>
          <select
            className="input-field"
            name="salaryRange"
            value={answers.salaryRange}
            onChange={handleInputChange}
          >
            <option value="" disabled>
              Select
            </option>
            <option value="1">Below Php 18,000.00</option>
            <option value="2">Php 18,000 - 25,000.00</option>
            <option value="3">Php 25,001.00 - 35,000.00</option>
            <option value="4">Php 35,001.00 - Php 45,000.00</option>
            <option value="5">Php 45,001 - Php 55,000.00</option>
            <option value="6">Above Php 55,000.00</option>
          </select>

          <div className="wd6-button-container">
            <button onClick={onBack}>Back</button>
            <button onClick={onNext} disabled={isNextDisabled}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD6;
