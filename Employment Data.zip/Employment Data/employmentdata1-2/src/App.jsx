import React, { useState } from 'react';
import WD1 from './Components/WD1';
import WD2 from './Components/WD2';
import WD3 from './Components/WD3';
import WD4 from './Components/WD4';
import WD5 from './Components/WD5';
import WD6 from './Components/WD6';
import WD7 from './Components/WD7';
import WD8 from './Components/WD8';

const App = () => {
  const [currentFrame, setCurrentFrame] = useState(1);
  const [employmentStatus, setEmploymentStatus] = useState(null);

  const goToNextFrame = () => {
    if (currentFrame === 1 && employmentStatus === 'never-employed') {
      setCurrentFrame(8);
    } else if (currentFrame === 8) {
      setCurrentFrame(5);
    } else if (currentFrame !== 5) {
      setCurrentFrame((prev) => Math.min(prev + 1, 8));
    }
  };

  const goToPreviousFrame = () => {
    if (currentFrame === 8) {
      setCurrentFrame(1);
    } else if (currentFrame === 5 && employmentStatus === 'never-employed') {
      setCurrentFrame(8);
    } else {
      setCurrentFrame((prev) => Math.max(prev - 1, 1));
    }
  };

  const handleEmploymentStatusChange = (status) => {
    setEmploymentStatus(status);
  };

  return (
    <div className="App">
      {currentFrame === 1 && (
        <WD1
          onNext={goToNextFrame}
          onEmploymentStatusChange={handleEmploymentStatusChange}
        />
      )}
      {currentFrame === 2 && <WD2 onNext={goToNextFrame} onBack={goToPreviousFrame} />}
      {currentFrame === 3 && <WD3 onNext={goToNextFrame} onBack={goToPreviousFrame} />}
      {currentFrame === 4 && <WD4 onNext={goToNextFrame} onBack={goToPreviousFrame} />}
      {currentFrame === 5 && <WD5 onNext={goToNextFrame} onBack={goToPreviousFrame} />}
      {currentFrame === 6 && <WD6 onNext={goToNextFrame} onBack={goToPreviousFrame} />}
      {currentFrame === 7 && <WD7 onNext={goToNextFrame} onBack={goToPreviousFrame} />}
      {currentFrame === 8 && <WD8 onBack={goToPreviousFrame} onNext={goToNextFrame} />}
    </div>
  );
};

export default App;