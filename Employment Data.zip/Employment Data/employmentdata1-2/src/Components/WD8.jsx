import React, { useState } from 'react';
import './WD8.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD8 = ({ onBack, onNext }) => {
  const [answers, setAnswers] = useState({
    advanceStudy: false,
    familyConcern: false,
    healthReasons: false,
    lackJobOpportunity: false,
    lackWorkExperience: false,
    notLookingForJob: false,
    inadequateSkills: false,
    otherChecked: false,
    other: '',
  });

  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    setAnswers((prev) => ({
      ...prev,
      [name]: checked,
    }));
  };

  const handleOtherChange = (event) => {
    setAnswers((prev) => ({
      ...prev,
      other: event.target.value,
    }));
  };

  const isNextDisabled = !(
    answers.advanceStudy ||
    answers.familyConcern ||
    answers.healthReasons ||
    answers.lackJobOpportunity ||
    answers.lackWorkExperience ||
    answers.notLookingForJob ||
    answers.inadequateSkills ||
    answers.other.trim() !== ''
  );

  return (
    <div className="wd8-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd8-overlay">
        <div className="wd8-content">
          <div className="wd8-header">
            <img src={logo} alt="Logo" className="wd8-logo" />
            <h1>Employment Data</h1>
          </div>

          <p>22. Please select the applicable reason/s why you are not currently employed or have never been employed:</p>
          <div className="choice-container">
            <label>
              <input
                type="checkbox"
                name="advanceStudy"
                checked={answers.advanceStudy}
                onChange={handleCheckboxChange}
              />
              Advance/Further Study
            </label>
            <label>
              <input
                type="checkbox"
                name="familyConcern"
                checked={answers.familyConcern}
                onChange={handleCheckboxChange}
              />
              Family-related concern
            </label>
            <label>
              <input
                type="checkbox"
                name="healthReasons"
                checked={answers.healthReasons}
                onChange={handleCheckboxChange}
              />
              Health reasons
            </label>
            <label>
              <input
                type="checkbox"
                name="lackJobOpportunity"
                checked={answers.lackJobOpportunity}
                onChange={handleCheckboxChange}
              />
              Lack of job opportunity
            </label>
            <label>
              <input
                type="checkbox"
                name="lackWorkExperience"
                checked={answers.lackWorkExperience}
                onChange={handleCheckboxChange}
              />
              Lack of work experience
            </label>
            <label>
              <input
                type="checkbox"
                name="notLookingForJob"
                checked={answers.notLookingForJob}
                onChange={handleCheckboxChange}
              />
              Did not look for a job
            </label>
            <label>
              <input
                type="checkbox"
                name="inadequateSkills"
                checked={answers.inadequateSkills}
                onChange={handleCheckboxChange}
              />
              Inadequate skill for the job
            </label>
            <label>
              <input
                type="checkbox"
                name="otherChecked"
                checked={answers.otherChecked}
                onChange={handleCheckboxChange}
              />
              Other (please specify):
            </label>
            {answers.otherChecked && (
              <input
                type="text"
                placeholder="Specify other reason"
                className="input-field"
                value={answers.other}
                onChange={handleOtherChange}
              />
            )}
          </div>

          <div className="wd8-button-container">
            <button onClick={onBack}>Back</button>
            <button onClick={onNext} disabled={isNextDisabled}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD8;