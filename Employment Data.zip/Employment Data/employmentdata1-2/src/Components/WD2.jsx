import React, { useState } from 'react';
import './WD2.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD2 = ({ onBack, onNext }) => {
  const [companyLocation, setCompanyLocation] = useState('');
  const [businessLine, setBusinessLine] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [currentPosition, setCurrentPosition] = useState('');
  const [country, setCountry] = useState('');
  const [otherBusinessLine, setOtherBusinessLine] = useState('');

  const handleLocationChange = (event) => {
    setCompanyLocation(event.target.value);
    if (event.target.value !== 'abroad') {
      setCountry('');
    }
  };

  const handleBusinessLineChange = (event) => {
    setBusinessLine(event.target.value);
    if (event.target.value !== 'other') {
      setOtherBusinessLine('');
    }
  };

  const isNextDisabled = () => {

    if (!companyName || !companyLocation || !businessLine || !currentPosition) return true;
    if (companyLocation === 'abroad' && !country) return true;
    if (businessLine === 'other' && !otherBusinessLine) return true;
    return false;
  };

  return (
    <div className="wd2-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd2-overlay">
        <div className="wd2-header">
          <img src={logo} alt="Logo" className="wd1-logo" />
          <h1>Employment Data</h1>
        </div>
        <div className="wd2-content">
          <div className="wd2-form">
            <p>23. Name of company, organization, or institution where you are currently connected *</p>
            <input
              type="text"
              placeholder="Enter your answer"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
            />

            <p>24. Company Location *</p>
            <div className="choice-container">
              <label>
                <input
                  type="radio"
                  name="companyLocation"
                  value="local"
                  checked={companyLocation === 'local'}
                  onChange={handleLocationChange}
                />{' '}
                Local
              </label>
              <label>
                <input
                  type="radio"
                  name="companyLocation"
                  value="abroad"
                  checked={companyLocation === 'abroad'}
                  onChange={handleLocationChange}
                />{' '}
                Abroad
              </label>
            </div>

            {companyLocation === 'abroad' && (
              <>
                <p>25. Country *</p>
                <input
                  type="text"
                  placeholder="Enter your answer"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                />
              </>
            )}

            <p>26. Major line of business of the company/organization/institution you are currently connected with *</p>
            <select value={businessLine} onChange={handleBusinessLineChange}>
              <option value="">Select</option>
              <option value="bpo">Business Process Outsourcing (BPO)</option>
              <option value="education">Education</option>
              <option value="engineering">Engineering and Construction</option>
              <option value="finance">Financial Services (banking, insurance, investment, tax, accounting, etc.)</option>
              <option value="government">Government (Local and National, including Regulatory Agencies)</option>
              <option value="health">Health Services</option>
              <option value="hospitality">Hospitality and Tourism</option>
              <option value="manufacturing">Manufacturing</option>
              <option value="ngo">Non-Government Organization (NGO)</option>
              <option value="pharmaceutical">Pharmaceutical Laboratories</option>
              <option value="planning">Planning and Design</option>
              <option value="realEstate">Real Estate</option>
              <option value="retail">Retail</option>
              <option value="telecom">Telecommunications</option>
              <option value="transport">Transportation and Logistics</option>
              <option value="other">Other</option>
            </select>

            {businessLine === 'other' && (
              <input
                type="text"
                placeholder="Enter your answer"
                value={otherBusinessLine}
                onChange={(e) => setOtherBusinessLine(e.target.value)}
              />
            )}

            <p>27. Current Position/Designation *</p>
            <input
              type="text"
              placeholder="Enter your answer"
              value={currentPosition}
              onChange={(e) => setCurrentPosition(e.target.value)}
            />

            <div className="wd2-button-container">
              <button onClick={onBack}>Back</button>
              <button onClick={onNext} disabled={isNextDisabled()}>
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD2;