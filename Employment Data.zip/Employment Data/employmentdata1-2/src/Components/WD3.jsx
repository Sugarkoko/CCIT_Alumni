import React, { useState } from 'react';
import './WD3.css'; 
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD3 = ({ onBack, onNext }) => {
  const [jobClassification, setJobClassification] = useState('');
  const [otherJob, setOtherJob] = useState(''); 
  const [isFirstJob, setIsFirstJob] = useState('');

  const isNextDisabled = () => {
    return (
      !jobClassification || 
      (jobClassification === 'others' && !otherJob.trim()) || 
      isFirstJob === ''
    );
  };

  return (
    <div className="wd3-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd3-overlay">
        <div className="wd3-content">
          <div className="wd3-header">
            <img src={logo} alt="Logo" className="wd3-logo" />
            <h1>Employment Data</h1>
          </div>

        
          <p>28. Current Job Classification *</p>
          <div className="choice-container">
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="entryLevel"
                checked={jobClassification === 'entryLevel'}
                onChange={(e) => {
                  setJobClassification(e.target.value);
                  setOtherJob(''); 
                }}
              />{' '}
              Entry-Level (e.g.: Staff Member, Representative, Associate)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="firstLevel"
                checked={jobClassification === 'firstLevel'}
                onChange={(e) => {
                  setJobClassification(e.target.value);
                  setOtherJob('');
                }}
              />{' '}
              First-Level Management (e.g.: Manager, Supervisor, Team Leader)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="middleManagement"
                checked={jobClassification === 'middleManagement'}
                onChange={(e) => {
                  setJobClassification(e.target.value);
                  setOtherJob('');
                }}
              />{' '}
              Middle Management (e.g.: Director, Regional Manager, Adviser)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="seniorManagement"
                checked={jobClassification === 'seniorManagement'}
                onChange={(e) => {
                  setJobClassification(e.target.value);
                  setOtherJob('');
                }}
              />{' '}
              Executive or Senior Management (e.g.: Chief Officers, Executive, VP, President)
            </label>
            <label>
              <input
                type="radio"
                name="jobClassification"
                value="others"
                checked={jobClassification === 'others'}
                onChange={(e) => setJobClassification(e.target.value)}
              />{' '}
              Others
            </label>

          
            {jobClassification === 'others' && (
              <input
                type="text"
                placeholder="Others"
                value={otherJob}
                onChange={(e) => setOtherJob(e.target.value)}
                className="others-textbox"
              />
            )}
          </div>

          
          <p>29. Is this your first job? *</p>
          <div className="choice-container">
            <label>
              <input
                type="radio"
                name="isFirstJob"
                value="yes"
                checked={isFirstJob === 'yes'}
                onChange={(e) => setIsFirstJob(e.target.value)}
              />{' '}
              Yes
            </label>
            <label>
              <input
                type="radio"
                name="isFirstJob"
                value="no"
                checked={isFirstJob === 'no'}
                onChange={(e) => setIsFirstJob(e.target.value)}
              />{' '}
              No
            </label>
          </div>

         
          <div className="wd3-button-container">
            <button onClick={onBack}>Back</button>
            <button onClick={onNext} disabled={isNextDisabled()}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD3;
