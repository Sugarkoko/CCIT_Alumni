import React, { useState } from "react";
import "./WD4.css";
import backgroundImage from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";

const WD4 = ({ onBack, onNext }) => {
  const [salaryRange, setSalaryRange] = useState("");
  const [timeToFirstJob, setTimeToFirstJob] = useState("");
  const [jobSource, setJobSource] = useState("");
  const [otherSource, setOtherSource] = useState("");

  const isNextDisabled = () => {
    return (
      !salaryRange ||
      !timeToFirstJob ||
      (!jobSource || (jobSource === "others" && !otherSource.trim()))
    );
  };

  return (
    <div
      className="wd4-container"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="wd4-overlay">
        <div className="wd4-content">
          <div className="wd4-header">
            <img src={logo} alt="Logo" className="wd4-logo" />
            <h1>Employment Data</h1>
          </div>
          <div className="wd4-form">
            <p>30. Salary Range *</p>
            <select
              value={salaryRange}
              onChange={(e) => setSalaryRange(e.target.value)}
            >
              <option value="">Select</option>
              <option value="1">Below Php 18,000.00</option>
              <option value="2">Php 18,000.00 - Php 25,000.00</option>
              <option value="3">Php 25,001.00 - Php 35,000.00</option>
              <option value="4">Php 35,001.00 - Php 45,000.00</option>
              <option value="5">Php 45,001.00 - Php 55,000.00</option>
              <option value="6">Above Php 55,000.00</option>
            </select>

            <p>
              31. How long did it take you to land your first job after
              graduation? *
            </p>
            <div className="choice-container">
              <label>
                <input
                  type="radio"
                  name="timeToFirstJob"
                  value="withinAMonth"
                  checked={timeToFirstJob === "withinAMonth"}
                  onChange={(e) => setTimeToFirstJob(e.target.value)}
                />{" "}
                Within a month
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToFirstJob"
                  value="lessThan6Months"
                  checked={timeToFirstJob === "lessThan6Months"}
                  onChange={(e) => setTimeToFirstJob(e.target.value)}
                />{" "}
                Less than 6 months
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToFirstJob"
                  value="6To11Months"
                  checked={timeToFirstJob === "6To11Months"}
                  onChange={(e) => setTimeToFirstJob(e.target.value)}
                />{" "}
                6 to 11 months
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToFirstJob"
                  value="1To2Years"
                  checked={timeToFirstJob === "1To2Years"}
                  onChange={(e) => setTimeToFirstJob(e.target.value)}
                />{" "}
                1 year but less than 2 years
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToFirstJob"
                  value="2To3Years"
                  checked={timeToFirstJob === "2To3Years"}
                  onChange={(e) => setTimeToFirstJob(e.target.value)}
                />{" "}
                2 years but less than 3 years
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToFirstJob"
                  value="3YearsAndAbove"
                  checked={timeToFirstJob === "3YearsAndAbove"}
                  onChange={(e) => setTimeToFirstJob(e.target.value)}
                />{" "}
                3 years and above
              </label>
            </div>

            <p>32. How did you find your first job? *</p>
            <div className="choice-container">
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="agency"
                  checked={jobSource === "agency"}
                  onChange={(e) => {
                    setJobSource(e.target.value);
                    setOtherSource("");
                  }}
                />{" "}
                Agency
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="jobFair"
                  checked={jobSource === "jobFair"}
                  onChange={(e) => {
                    setJobSource(e.target.value);
                    setOtherSource("");
                  }}
                />{" "}
                Career Job Fair at NU
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="internship"
                  checked={jobSource === "internship"}
                  onChange={(e) => {
                    setJobSource(e.target.value);
                    setOtherSource("");
                  }}
                />{" "}
                Internship/OJT/Practicum
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="ownBusiness"
                  checked={jobSource === "ownBusiness"}
                  onChange={(e) => {
                    setJobSource(e.target.value);
                    setOtherSource("");
                  }}
                />{" "}
                I started my own company/business
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="jobAdvertisement"
                  checked={jobSource === "jobAdvertisement"}
                  onChange={(e) => {
                    setJobSource(e.target.value);
                    setOtherSource("");
                  }}
                />{" "}
                Job Advertisement
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="recommendation"
                  checked={jobSource === "recommendation"}
                  onChange={(e) => {
                    setJobSource(e.target.value);
                    setOtherSource("");
                  }}
                />{" "}
                Recommended by someone
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="others"
                  checked={jobSource === "others"}
                  onChange={(e) => setJobSource(e.target.value)}
                />{" "}
                Others
              </label>

              {jobSource === "others" && (
                <input
                  type="text"
                  placeholder="Others"
                  value={otherSource}
                  onChange={(e) => setOtherSource(e.target.value)}
                  className="others-textbox"
                />
              )}
            </div>

            <div className="wd4-button-container">
              <button onClick={onBack}>Back</button>
              <button onClick={onNext} disabled={isNextDisabled()}>
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD4;