import React, { useState } from 'react';
import './WD7.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD7 = ({ onBack, onNext }) => {
  const [answers, setAnswers] = useState({
    relatedToDegree: null,
    timeToJob: null,
    jobSource: null,
    jobSourceOther: '',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setAnswers((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleOtherInputChange = (event) => {
    setAnswers((prev) => ({
      ...prev,
      jobSourceOther: event.target.value,
    }));
  };

  const isNextDisabled =
    !answers.relatedToDegree ||
    !answers.timeToJob ||
    (!answers.jobSource && answers.jobSourceOther.trim() === '');

  return (
    <div className="wd7-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd7-overlay">
        <div className="wd7-content">
          <div className="wd7-header">
            <img src={logo} alt="Logo" className="wd7-logo" />
            <h1>Employment Data</h1>
          </div>
          <div className="wd7-form">
            <p>34. Is this your first job related to the degree you completed? *</p>
            <div className="choice-container">
              <label>
                <input
                  type="radio"
                  name="relatedToDegree"
                  value="Yes"
                  onChange={handleInputChange}
                />
                Yes
              </label>
              <label>
                <input
                  type="radio"
                  name="relatedToDegree"
                  value="No"
                  onChange={handleInputChange}
                />
                No
              </label>
            </div>

            <p>35. How long did it take you to land your first job after graduation? *</p>
            <div className="choice-container">
              <label>
                <input
                  type="radio"
                  name="timeToJob"
                  value="Within a month"
                  onChange={handleInputChange}
                />
                Within a month
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToJob"
                  value="Less than 6 months"
                  onChange={handleInputChange}
                />
                Less than 6 months
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToJob"
                  value="6 to 11 months"
                  onChange={handleInputChange}
                />
                6 to 11 months
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToJob"
                  value="1 year but less than 2 years"
                  onChange={handleInputChange}
                />
                1 year but less than 2 years
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToJob"
                  value="2 years but less than 3 years"
                  onChange={handleInputChange}
                />
                2 years but less than 3 years
              </label>
              <label>
                <input
                  type="radio"
                  name="timeToJob"
                  value="3 years and above"
                  onChange={handleInputChange}
                />
                3 years and above
              </label>
            </div>

            <p>36. How did you find your first job? *</p>
            <div className="choice-container">
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Agency"
                  onChange={handleInputChange}
                />
                Agency
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Career/Job Fair at NU"
                  onChange={handleInputChange}
                />
                Career/Job Fair at NU
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Internship/OJT/Practicum"
                  onChange={handleInputChange}
                />
                Internship/OJT/Practicum
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Started my own business"
                  onChange={handleInputChange}
                />
                I started at my own company/business
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Job Advertisement"
                  onChange={handleInputChange}
                />
                Job Advertisement
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Recommended by someone"
                  onChange={handleInputChange}
                />
                Recommended by someone
              </label>
              <label>
                <input
                  type="radio"
                  name="jobSource"
                  value="Others"
                  onChange={handleInputChange}
                />
                Others
              </label>
              {answers.jobSource === 'Others' && (
                <input
                  type="text"
                  placeholder="Please specify"
                  className="input-field"
                  value={answers.jobSourceOther}
                  onChange={handleOtherInputChange}
                />
              )}
            </div>

            <div className="wd7-button-container">
              <button onClick={onBack}>Back</button>
              <button onClick={onNext} disabled={isNextDisabled}>
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD7;