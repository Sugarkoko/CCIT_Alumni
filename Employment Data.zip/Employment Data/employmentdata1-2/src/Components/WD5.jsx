import React, { useState } from 'react';
import './WD5.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const WD5 = ({ onBack, onNext }) => {
  const [isEntrepreneur, setIsEntrepreneur] = useState('');
  const [entrepreneurDetails, setEntrepreneurDetails] = useState('');

  const isNextDisabled = () => {
    return isEntrepreneur === '' || (isEntrepreneur === 'yes' && entrepreneurDetails.trim() === '');
  };

  return (
    <div className="wd5-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="wd5-overlay">
        <div className="wd5-content">
          <div className="wd5-header">
            <img src={logo} alt="Logo" className="wd5-logo" />
            <h1>Employment Data</h1>
          </div>

          <p>37. Are you engaged in entrepreneurship? *</p>
          <div className="choice-container">
            <label>
              <input
                type="radio"
                name="isEntrepreneur"
                value="yes"
                checked={isEntrepreneur === 'yes'}
                onChange={(e) => {
                  setIsEntrepreneur(e.target.value);
                  setEntrepreneurDetails('');
                }}
              />{' '}
              Yes
            </label>
            <label>
              <input
                type="radio"
                name="isEntrepreneur"
                value="no"
                checked={isEntrepreneur === 'no'}
                onChange={(e) => {
                  setIsEntrepreneur(e.target.value);
                  setEntrepreneurDetails('');
                }}
              />{' '}
              No
            </label>
          </div>

          {isEntrepreneur === 'yes' && (
            <>
              <p>38. Please give a brief description of your entrepreneurial engagement. *</p>
              <textarea
                value={entrepreneurDetails}
                onChange={(e) => setEntrepreneurDetails(e.target.value)}
                placeholder="Enter your answer"
              ></textarea>
            </>
          )}

          <div className="wd5-button-container">
            <button onClick={onBack}>Back</button>
            <button onClick={onNext} disabled={isNextDisabled()}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WD5;
