import React from "react";
import { useNavigate } from "react-router-dom";
import "./Reg1.css";
import background from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";

const Reg1 = () => {
  const navigate = useNavigate();

  const handleStartNow = () => {
    navigate("/registration-details"); 
  };

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-header">
          <div className="signup-header-row">
            <img src={logo} alt="Blue Logo" className="signup-logo" />
            <h1>Alumni Sign up Form</h1>
          </div>
          <p>This form aims to gather current information from our Alumnus/Alumna.</p>
        </div>
        <div className="signup-actions">
          <button className="back-btn">Back</button>
          <button className="start-btn" onClick={handleStartNow}>Start Now</button>
        </div>
      </div>
    </div>
  );
};

export default Reg1;
