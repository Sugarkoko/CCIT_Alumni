import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg2.css";
import background from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";

const Reg2 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    program: "",
    yearGraduated: "",
    educationLevel: [],
  });

  const handleBack = () => {
    navigate("/alumni-signup");
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    setFormData((prevState) => {
      const updatedLevels = checked
        ? [...prevState.educationLevel, value]
        : prevState.educationLevel.filter((level) => level !== value);
      return { ...prevState, educationLevel: updatedLevels };
    });
  };

  const isFormComplete =
    formData.fullName.trim() &&
    formData.program.trim() &&
    formData.yearGraduated.trim() &&
    formData.educationLevel.length > 0;

  const handleNext = () => {
    if (isFormComplete) {
      navigate("/additional-details"); 
    }
  };

  return (
    <div
      className="signup-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="signup-overlay">
        <div className="signup-header">
          <div className="signup-header-row">
            <img src={logo} alt="Blue Logo" className="signup-logo" />
            <h1>Alumni Sign up</h1>
          </div>
        </div>
        <div className="signup-form">
          <label>1. Full Name (First Name, Middle Name, Last Name)</label>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            placeholder="Enter your answer"
            onChange={handleInputChange}
          />

          <label>2. Program/Course</label>
          <input
            type="text"
            name="program"
            value={formData.program}
            placeholder="Enter your answer"
            onChange={handleInputChange}
          />

          <label>3. Year Graduated (e.g., May 2018)</label>
          <input
            type="text"
            name="yearGraduated"
            value={formData.yearGraduated}
            placeholder="Enter your answer"
            onChange={handleInputChange}
          />

          <label>4. Educational level completed</label>
          <div className="checkbox-group">
            <label>
              <input
                type="checkbox"
                value="Elementary"
                onChange={handleCheckboxChange}
                checked={formData.educationLevel.includes("Elementary")}
              />
              Elementary
            </label>
            <label>
              <input
                type="checkbox"
                value="High School"
                onChange={handleCheckboxChange}
                checked={formData.educationLevel.includes("High School")}
              />
              High School
            </label>
            <label>
              <input
                type="checkbox"
                value="Associate's Degree"
                onChange={handleCheckboxChange}
                checked={formData.educationLevel.includes("Associate's Degree")}
              />
              Associate's Degree
            </label>
            <label>
              <input
                type="checkbox"
                value="Bachelor's Degree"
                onChange={handleCheckboxChange}
                checked={formData.educationLevel.includes("Bachelor's Degree")}
              />
              Bachelor's Degree
            </label>
            <label>
              <input
                type="checkbox"
                value="Master's Degree"
                onChange={handleCheckboxChange}
                checked={formData.educationLevel.includes("Master's Degree")}
              />
              Master's Degree
            </label>
            <label>
              <input
                type="checkbox"
                value="Doctor's Degree"
                onChange={handleCheckboxChange}
                checked={formData.educationLevel.includes("Doctor's Degree")}
              />
              Doctor's Degree
            </label>
          </div>
        </div>
        <div className="signup-actions">
          <button className="back-btn" onClick={handleBack}>
            Back
          </button>
          <button
            className="next-btn"
            onClick={handleNext}
            disabled={!isFormComplete} 
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reg2;
