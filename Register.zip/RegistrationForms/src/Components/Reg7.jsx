import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg7.css";
import background from "../assets/Background.jpeg";

const Reg7 = () => {
  const [verificationCode, setVerificationCode] = useState("");
  const [isResendPopupVisible, setIsResendPopupVisible] = useState(false);
  const [isWelcomePopupVisible, setIsWelcomePopupVisible] = useState(false);
  const navigate = useNavigate();

  const handleBackClick = () => {
    navigate("/review-form");
  };

  const handleChange = (e) => {
    setVerificationCode(e.target.value);
  };

  const handleResend = () => {
    setIsResendPopupVisible(true);
    setTimeout(() => setIsResendPopupVisible(false), 3000);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsWelcomePopupVisible(true);
  };

  const closeWelcomePopup = () => {
    setIsWelcomePopupVisible(false);
    navigate("/dashboard");
  };

  return (
    <div
      className="reg7-container"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="reg7-overlay">
        <div className="reg7-header">
          <h1>Verify Your Account</h1>
        </div>
        <div className="reg7-content">
          <p>
            Please enter the 6-digits verification code sent to your email to
            complete registration.
          </p>
          <form className="reg7-form" onSubmit={handleSubmit}>
            <input
              type="text"
              maxLength="6"
              placeholder="______"
              value={verificationCode}
              onChange={handleChange}
              className="reg7-input"
            />
            <p className="reg7-note">
              Note: This code is only valid for 10 minutes. If you didn’t
              receive a code, please check your spam folder or{" "}
              <a href="#resend" onClick={handleResend}>
                Resend
              </a>.
            </p>
            <div className="reg7-buttons">
              <button type="button" className="reg7-btn" onClick={handleBackClick}>
                Back
              </button>
              <button type="submit" className="reg7-btn">
                Done
              </button>
            </div>
          </form>
        </div>
      </div>
      {isResendPopupVisible && (
        <div className="popup">
          <p>
            A new verification code has been sent to your email. Please check
            your inbox and enter the code.
          </p>
          <button
            className="popup-btn"
            onClick={() => setIsResendPopupVisible(false)}
          >
            Close
          </button>
        </div>
      )}
      {isWelcomePopupVisible && (
        <div className="welcome-popup">
          <h2>Welcome to CCIT Alumni Connect!</h2>
          <p>To complete your account setup, please click Done to continue.</p>
          <button className="welcome-btn" onClick={closeWelcomePopup}>
            Done
          </button>
        </div>
      )}
    </div>
  );
};

export default Reg7;
