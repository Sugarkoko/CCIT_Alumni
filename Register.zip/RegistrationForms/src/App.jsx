import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Reg1 from "./Components/Reg1";
import Reg2 from "./Components/Reg2";
import Reg3 from "./Components/Reg3";
import Reg4 from "./Components/Reg4";
import Reg5 from "./Components/Reg5";
import Reg6 from "./Components/Reg6";
import Reg7 from "./Components/Reg7"; 

const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/alumni-signup" element={<Reg1 />} />
          <Route path="/registration-details" element={<Reg2 />} />
          <Route path="/additional-details" element={<Reg3 />} />
          <Route path="/final-details" element={<Reg4 />} />
          <Route path="/social-links" element={<Reg5 />} />
          <Route path="/review-form" element={<Reg6 />} />
          <Route path="/verify-account" element={<Reg7 />} /> 
          <Route path="*" element={<Reg1 />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;