import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Reg5.css";
import background from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";

const Reg5 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    linkedIn: "",
    facebook: "",
    instagram: "",
    password: "",
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleBack = () => {
    navigate("/final-details");
  };

  const handleSubmit = () => {
    console.log("Form data submitted:", formData);
    navigate("/review-form"); 
  };

  const isFormComplete =
    formData.linkedIn.trim() &&
    formData.facebook.trim() &&
    formData.instagram.trim() &&
    formData.password.trim();

  return (
    <div className="signup-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="signup-overlay">
        <div className="signup-content">
          <div className="signup-header">
            <div className="signup-header-row">
              <img src={logo} alt="Blue Logo" className="signup-logo" />
              <h1>Alumni Sign up</h1>
            </div>
          </div>
          <div className="signup-form">
            <label>13. LinkedIn Profile Link/Name</label>
            <input
              type="text"
              name="linkedIn"
              value={formData.linkedIn}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>14. Facebook Profile Link/Name</label>
            <input
              type="text"
              name="facebook"
              value={formData.facebook}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>15. Instagram Profile Link/Name</label>
            <input
              type="text"
              name="instagram"
              value={formData.instagram}
              placeholder="Enter your answer"
              onChange={handleInputChange}
            />

            <label>16. Set up your password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              placeholder="Enter your password"
              onChange={handleInputChange}
            />
            <div className="signup-actions">
              <button className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button
                className="next-btn"
                onClick={handleSubmit}
                disabled={!isFormComplete}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reg5;