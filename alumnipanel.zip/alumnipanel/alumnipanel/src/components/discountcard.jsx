import './discountcard.css'; // Keep the same CSS for now, but rename if you need

function DiscountCard({ discount }) { // Changed prop name to discount
  function onClickDiscount() {
    alert("Discount Clicked");
  }

  return (
    <div className="discount-card" onClick={onClickDiscount}> {/* Keeping the classname event-card for simplicity, or adjust if you have custom style}*/}
      <div className="discount-card__image"> {/* Keeping the classname event-card__image for simplicity */}
        <img src={discount.image} alt={discount.title} />
      </div>
     
    </div>
  );
}

export default DiscountCard;