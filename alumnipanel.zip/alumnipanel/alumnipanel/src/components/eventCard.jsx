// eventCard.jsx
import React from 'react';
import './eventCard.css';

function EventCard({ event }) {
    function onClickEvent() {
        alert("Event Clicked");
    }

    function onClickInterested(e){
      e.stopPropagation();
      alert("Interested button clicked!")
    }

    return (
        <div className="event-card" onClick={onClickEvent}>
            <div className="event-card__image">
                <img src={event.image} alt={event.title} />
            </div>
            <div className="event-card__content">
                <p className='event-date'>{event.date}</p>
                <h3 className='event-title'>{event.title}</h3>
                <p className='event-description'>{event.description}</p>
            </div>
            <button className="interested-button" onClick={onClickInterested}> Interested </button>
        </div>
    );
}

export default EventCard;