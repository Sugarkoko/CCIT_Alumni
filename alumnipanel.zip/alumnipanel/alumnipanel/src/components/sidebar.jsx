import DiscountCard from './discountcard.jsx';
import event1 from '../assets/sample.png';
import './sidebar.css';

function Sidebar() {
    return (
        <aside className="sidebar">
            <aside className="ProfileSidebar">
              <div className='profile-icon'></div>
                <div className='profile-text'>
                  <h2>Welcome, Alumni!</h2>
                  
                      
                    <p>National University - Manila</p>
                    <p>Bachelor of Science in Computer Science Graduate</p>
                    <p>Specialization in Machine Learning</p>
                    <p>Batch 2019</p>
                </div>
              <button className="update-info-button">Update Info</button>
            </aside>
            <aside className="DiscountSidebar">
                <h1 className='discountsidebar_Label'>Alumni Discounts</h1>
                <hr />
                <DiscountCard discount={{ title: "Discount 1", description: "This is the description of discount 1", image: event1, date: "Oct 26, 2023" }} />
                <DiscountCard discount={{ title: "Discount 2", description: "This is the description of discount 2", image: event1, date: "Oct 27, 2023" }} />
                <DiscountCard discount={{ title: "Discount 3", description: "This is the description of discount 3", image: event1, date: "Oct 28, 2023" }} />
                <DiscountCard discount={{ title: "Discount 4", description: "This is the description of discount 4", image: event1, date: "Oct 29, 2023" }} />
            </aside>
        </aside>
    );
}

export default Sidebar;