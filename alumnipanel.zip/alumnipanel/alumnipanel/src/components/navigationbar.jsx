import { useState } from 'react';
import logo from "../assets/Blue Logo.png";
import eventsIcon from "../assets/EventsIcon.png";
import messageIcon from "../assets/MessageIcon.png";
import notificationIcon from "../assets/NotifIcon.png";
import feedbackIcon from "../assets/FeedbackIcon.png";

import './navbar.css';

function NavBar() {
    const [searchValue, setSearchValue] = useState('');

    const handleSearchSubmit = (event) => {
        event.preventDefault();
        // Here you would handle the search logic using searchValue
        console.log('Searching for:', searchValue);
        //reset the input field
        setSearchValue("");
    };

    const handleInputChange = (event) => {
    setSearchValue(event.target.value);
  };

    const navItems = [
        { id: 1, label: 'Events', icon: eventsIcon, href: '/Events' },
        { id: 2, label: 'Message', icon: messageIcon, href: '/Messages' },
        { id: 3, label: 'Notification', icon: notificationIcon, href: '/Notifications' },
        { id: 4, label: 'Feedback', icon: feedbackIcon, href: '/Feedback' },
    ];
    return (
      <nav className="navbar">
        <div className="container">
            <div className="logo">
            <img src={logo} alt="Logo" className="navbar-logo" />
          </div>
          <form className="search-form" role="search" onSubmit={handleSearchSubmit}>
            <input
              className="search-input"
              type="search"
              placeholder="Search..."
              aria-label="Search"
                value={searchValue}
                onChange={handleInputChange}
            />
          </form>
          <ul className="nav-links">
          {navItems.map((item) => (
            <li className="nav-item" key={item.id}>
              <a className="nav-link" href={item.href}>
                <span className="nav-icon">
                  <img src={item.icon} alt={item.label} className="nav-item-image"/>
                </span>
                <span className="nav-label">{item.label}</span>
              </a>
            </li>
          ))}
        </ul>
          
        </div>
      </nav>
    );
  }
export default NavBar;