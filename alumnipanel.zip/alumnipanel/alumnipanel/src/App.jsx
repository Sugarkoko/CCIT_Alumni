// App.jsx
import EventCard from './components/eventCard.jsx';
import Navbar from './components/navigationbar.jsx';
import './index.css'; // Import the CSS for App component
import event1 from './assets/sample.png';
import Sidebar from './components/sidebar.jsx';

function App() {
  return (
    <div className="app-container">
      <Navbar />
      <div className="content-area">
      
      <Sidebar />
       
        <main className="main-content">
          <div className="events-container">
            <div className='EventsLabel'>
              <h2>Discover Events</h2>
              <button className="create-event-button">Create Event</button>
            </div>
            <EventCard event={{ title: "Event 1", description: "This is the description of event 1", image: event1, date: "Oct 26, 2023" }} />
            <EventCard event={{ title: "Event 2", description: "This is the description of event 1", image: event1, date: "Oct 27, 2023" }} />
            <EventCard event={{ title: "Event 3", description: "This is the description of event 1", image: event1, date: "Oct 28, 2023" }} />
            <EventCard event={{ title: "Event 4", description: "This is the description of event 1", image: event1, date: "Oct 29, 2023" }} />
            <EventCard event={{ title: "Event 5", description: "This is the description of event 1", image: event1, date: "Oct 30, 2023" }} />
            <EventCard event={{ title: "Event 6", description: "This is the description of event 1", image: event1, date: "Oct 31, 2023" }} />
            <EventCard event={{ title: "Event 1", description: "This is the description of event 1", image: event1, date: "Oct 26, 2023" }} />
            <EventCard event={{ title: "Event 2", description: "This is the description of event 1", image: event1, date: "Oct 27, 2023" }} />
            <EventCard event={{ title: "Event 3", description: "This is the description of event 1", image: event1, date: "Oct 28, 2023" }} />
            <EventCard event={{ title: "Event 4", description: "This is the description of event 1", image: event1, date: "Oct 29, 2023" }} />
            <EventCard event={{ title: "Event 5", description: "This is the description of event 1", image: event1, date: "Oct 30, 2023" }} />
            <EventCard event={{ title: "Event 6", description: "This is the description of event 1", image: event1, date: "Oct 31, 2023" }} />
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;