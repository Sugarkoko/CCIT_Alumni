import React from "react";
import { useNavigate } from "react-router-dom";
import "./NA3.css";
import background from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";
import checkmark from "../assets/checkmark.png";

const NA3 = () => {
  const navigate = useNavigate();

  const handleContinue = () => {
    console.log("Continue clicked, staying on this page.");
  };

  return (
    <div className="na3-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="na3-overlay">
        <img src={logo} alt="Logo" className="na3-logo" />
        <img src={checkmark} alt="Success" className="na3-checkmark" />
        <h2 className="na3-message">Congratulations, you're all set!</h2>
        <button className="na3-continue-btn" onClick={handleContinue}>
          Continue
        </button>
      </div>
    </div>
  );
};

export default NA3;
