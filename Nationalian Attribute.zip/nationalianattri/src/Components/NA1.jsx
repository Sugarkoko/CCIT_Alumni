import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./NA1.css";
import background from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";

const NA1 = () => {
  const navigate = useNavigate();
  const [answers, setAnswers] = useState({});

  const attributes = [
    "Exhibiting moral, ethical, and competent leadership",
    "Collaborating effectively in teams of different cultures",
    "Participating actively in community-oriented advocacies that contribute to nation building",
    "Possessing an entrepreneurial mindset",
    "Providing solutions to challenges in my field of specialization and society in general",
    "Demonstrating mastery of foundational skills and in my specialization",
    "Expressing ideas meaningfully, accurately, and appropriately in multicultural and multidisciplinary contexts",
    "Practicing the NU Core Values",
    "Engaging in continuing personal and professional development",
    "Demonstrating the capacity for self-reflection",
    "Demonstrating adaptability, flexibility, productivity, and accountability in diverse settings",
    "Exhibiting mastery in navigating various technological tools and techniques",
  ];

  const handleChange = (index, value) => {
    setAnswers((prev) => ({
      ...prev,
      [index]: value,
    }));
  };

  return (
    <div className="na-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="na-overlay">
        <div className="na-header">
          <div className="na-header-row">
            <img src={logo} alt="Blue Logo" className="na-logo" />
            <h1>Nationalian Attributes and Core Values</h1>
          </div>
          <div className="na-subheader">
            <p className="na-instruction">
              <span className="na-number">26.</span> Please rate the importance of the following attributes to your personal and professional life.
            </p>
          </div>
        </div>

        <form className="na-form">
          {attributes.map((attribute, index) => (
            <div key={index} className="na-question">
              <p className="na-question-text">{attribute}</p>
              <div className="na-options">
                {["Not Important", "Slightly Important", "Important", "Very Important", "Extremely Important"].map((level, i) => (
                  <label key={i} className="na-label">
                    <input
                      type="radio"
                      name={`attribute-${index}`}
                      value={level}
                      onChange={() => handleChange(index, level)}
                      required
                    />
                    {level}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </form>

        <div className="na-actions">
          <button className="na-back-btn" onClick={() => navigate(-1)}>
            Back
          </button>
          <button 
            className="na-next-btn" 
            onClick={() => navigate("/next-page")} 
            disabled={Object.keys(answers).length !== attributes.length}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default NA1;
