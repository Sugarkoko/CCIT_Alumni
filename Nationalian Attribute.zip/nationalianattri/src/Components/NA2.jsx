import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./NA2.css";
import background from "../assets/Background.jpeg";
import logo from "../assets/Blue Logo.png";

const NA2 = () => {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [answers, setAnswers] = useState({});
  const [isFormComplete, setIsFormComplete] = useState(false);

  const questions = [
    "Content and expertise (skills and competencies)",
    "Working effectively (attitude, team player, professionalism)",
    "Interpersonal communication",
    "Growth at work (promotion)",
    "Personal/Professional development",
  ];

  const checkFormCompletion = (updatedAnswers) => {
    const allAnswered = questions.every((_, index) => updatedAnswers[`question-${index}`]);
    setIsFormComplete(allAnswered);
  };

  const handleChange = (event, index) => {
    const updatedAnswers = { ...answers, [`question-${index}`]: event.target.value };
    setAnswers(updatedAnswers);
    checkFormCompletion(updatedAnswers);
  };

  const handleBack = () => {
    navigate("/");
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setShowModal(true);
  };

  const handleConfirmSubmit = () => {
    setShowModal(false);
    navigate("/na3");
  };

  const handleCancel = () => {
    setShowModal(false);
  };

  return (
    <div className="na-container" style={{ backgroundImage: `url(${background})` }}>
      <div className="na-overlay">
        <div className="na-header">
          <div className="na-header-row">
            <img src={logo} alt="Blue Logo" className="na-logo" />
            <h1>Nationalian Attributes and Core Values</h1>
          </div>
        </div>

        <p className="na-instruction">
          <span className="na-number">33.</span> Select the Nationalian core value/s that are significant in your profession:
        </p>
        <div className="na-question">
          <div className="na-options na-options-column">
            {["Compassion", "Innovation", "Integrity", "Resilience", "Patriotism"].map((value, index) => (
              <label key={index} className="na-label">
                <input type="checkbox" name="core-values" value={value} />
                {value}
              </label>
            ))}
          </div>
        </div>

        <p className="na-instruction">
          <span className="na-number">34.</span> To what extent has your education in NU helped you in your employment vis-a-vis:
        </p>
        <form onSubmit={handleSubmit}>
          {questions.map((question, index) => (
            <div key={index} className="na-question">
              <p className="na-question-text">{question}</p>
              <div className="na-options na-options-radio">
                {["Not Helpful", "Slightly Helpful", "Helpful", "Very Helpful", "Extremely Helpful"].map((level, i) => (
                  <label key={i} className="na-label na-radio-label">
                    <input
                      type="radio"
                      name={`question-${index}`}
                      value={level}
                      onChange={(e) => handleChange(e, index)}
                      required
                    />
                    <span>{level}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}

          <div className="na-actions">
            <button className="na-back-btn" type="button" onClick={handleBack}>
              Back
            </button>
            <button className="na-next-btn" type="submit" disabled={!isFormComplete}>
              Submit
            </button>
          </div>
        </form>

        {showModal && (
          <div className="na-modal-overlay">
            <div className="na-modal">
              <h2>Are you sure you want to submit?</h2>
              <p>Please confirm that all your information is correct before submitting.</p>
              <div className="na-modal-actions">
                <button className="na-modal-cancel" onClick={handleCancel}>
                  Cancel
                </button>
                <button className="na-modal-submit" onClick={handleConfirmSubmit}>
                  Submit
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default NA2;
