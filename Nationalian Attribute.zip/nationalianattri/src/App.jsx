import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NA1 from "./Components/NA1";
import NA2 from "./Components/NA2";
import NA3 from "./Components/NA3"; 

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<NA1 />} />
        <Route path="/next-page" element={<NA2 />} />
        <Route path="/na3" element={<NA3 />} /> {}
      </Routes>
    </Router>
  );
};

export default App;
