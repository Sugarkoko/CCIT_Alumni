import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LogIn from "./Components/LogIn";
import ResetPass from "./Components/ResetPass";
import Authentication from "./Components/Authentication"; 

const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/login" element={<LogIn />} /> {/* Updated route */}
          <Route path="/reset-password" element={<ResetPass />} />
          <Route path="/authentication" element={<Authentication />} /> {/* New route */}
          <Route path="*" element={<LogIn />} /> {/* Redirect unknown routes to LogIn */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
