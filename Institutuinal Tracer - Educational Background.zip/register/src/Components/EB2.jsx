import React, { useState } from 'react';
import './TracerTool.css';
import './EB2.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const EB2 = ({ onBack, onNext, lastQuestionNumber = 0 }) => {
  const [formData, setFormData] = useState({
    honors: [],
    furtherStudies: '',
    additionalEducation: '',
    otherHonor: '',
    otherFurtherStudies: '',
  });


  const sanitizedQuestionNumber = Number.isFinite(lastQuestionNumber)
    ? lastQuestionNumber
    : 0;

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      honors: checked
        ? [...prev.honors, value]
        : prev.honors.filter((honor) => honor !== value),
    }));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const isFormComplete = () =>
    formData.furtherStudies !== '' &&
    (formData.furtherStudies !== 'Other' || formData.otherFurtherStudies.trim() !== '');

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isFormComplete()) {
      alert('Please complete all required fields before proceeding.');
      return;
    }
    console.log('Form submitted:', formData);
    onNext();
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>Educational Background</h1>
          </div>
          <form onSubmit={handleSubmit}>
            
            <div className="question">
              <p>{sanitizedQuestionNumber + 1}. Honors or Awards Received, if any:</p>
              <label>
                <input
                  type="checkbox"
                  value="Cum Laude"
                  onChange={handleCheckboxChange}
                />{' '}
                Cum Laude
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Magna Cum Laude"
                  onChange={handleCheckboxChange}
                />{' '}
                Magna Cum Laude
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Summa Cum Laude"
                  onChange={handleCheckboxChange}
                />{' '}
                Summa Cum Laude
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Don Mariano Jhocson Memorial Award"
                  onChange={handleCheckboxChange}
                />{' '}
                Don Mariano Jhocson Memorial Award
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Loyalty Award"
                  onChange={handleCheckboxChange}
                />{' '}
                Loyalty Award
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Other"
                  onChange={(e) => {
                    handleCheckboxChange(e);
                    if (!e.target.checked) {
                      setFormData((prev) => ({ ...prev, otherHonor: '' }));
                    }
                  }}
                />{' '}
                Others
              </label>
              {formData.honors.includes('Other') && (
                <input
                  type="text"
                  name="otherHonor"
                  value={formData.otherHonor}
                  onChange={handleInputChange}
                  placeholder="Please specify"
                />
              )}
            </div>

            
            <div className="question">
              <p>{sanitizedQuestionNumber + 2}. Further studies you are currently pursuing *</p>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Master's"
                  onChange={handleInputChange}
                  required
                />{' '}
                Master's
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Doctoral"
                  onChange={handleInputChange}
                  required
                />{' '}
                Doctoral
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Another Baccalaureate Degree"
                  onChange={handleInputChange}
                  required
                />{' '}
                Another Baccalaureate Degree
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Bachelor of Laws"
                  onChange={handleInputChange}
                  required
                />{' '}
                Bachelor of Laws
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Graduate Diploma/Certificate"
                  onChange={handleInputChange}
                  required
                />{' '}
                Graduate Diploma/Certificate
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Certification"
                  onChange={handleInputChange}
                  required
                />{' '}
                Certification
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="None"
                  onChange={handleInputChange}
                  required
                />{' '}
                None
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Other"
                  onChange={(e) => {
                    handleInputChange(e);
                    if (e.target.checked) {
                      setFormData((prev) => ({ ...prev, otherFurtherStudies: '' }));
                    }
                  }}
                  required
                />{' '}
                Others
              </label>
              {formData.furtherStudies === 'Other' && (
                <input
                  type="text"
                  name="otherFurtherStudies"
                  value={formData.otherFurtherStudies}
                  onChange={handleInputChange}
                  placeholder="Please specify"
                  required
                />
              )}
            </div>

            
            <div className="question">
              <p>{sanitizedQuestionNumber + 3}. (If none or others), Please share any additional education or certifications you have completed, including program name/title, completion year, and institution attended. </p>
              <textarea
                name="additionalEducation"
                value={formData.additionalEducation}
                onChange={handleInputChange}
                placeholder="Enter your answer"
              />
            </div>

            
            <div className="button-container">
              <div className="back-button-container">
                <button type="button" onClick={onBack}>
                  Back
                </button>
              </div>
              <div className="next-button-container">
                <button type="submit" disabled={!isFormComplete()}>
                  Next
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EB2;
