import React, { useState, useContext } from 'react';
import { AppContext } from '../App';
import './TracerTool.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const TracerTool = ({ onFormComplete }) => {
  const [isAgreed, setIsAgreed] = useState(false);

  const handleAgreeChange = () => {
    setIsAgreed(true);
  };

  const handleDisagreeChange = () => {
    setIsAgreed(false);
  };

  const handleNextPage = () => {
    onFormComplete();
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>INSTITUTIONAL TRACER TOOL</h1>
          </div>
          <p>
            Dear Graduate,<br />
            You are invited to participate in this survey to get feedback on your work, advanced studies, and other
            activities since you graduated from National University. Kindly complete the survey accurately as your
            responses are valuable inputs to continuously improve the quality of education at the University. Rest
            assured that your responses will be treated with the utmost confidentiality and will only be used for the
            purpose stated in the Data Privacy Notice.
          </p>
          <p>
            I understand and agree that by filling out and submitting this form, I am allowing National University to
            collect, process, use, share, and disclose my personal information and responses for alumni databasing as
            reference for alumni activities, employment opportunities, graduate employability and planning future
            educational needs; and to store it as long as necessary for the fulfillment of the stated purpose and in
            accordance with applicable laws, including the Data Privacy Act of 2012 and its Implementing Rules and
            Regulations, and the National University Privacy Policy.
          </p>
          <div className="options">
            <label>
              <input type="radio" name="agreement" checked={isAgreed} onChange={handleAgreeChange} /> I agree
            </label>
            <label>
              <input type="radio" name="agreement" checked={!isAgreed} onChange={handleDisagreeChange} /> I disagree
            </label>
          </div>
          <div className="button-container">
            <button disabled={!isAgreed} onClick={handleNextPage}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TracerTool;