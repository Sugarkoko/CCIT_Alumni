import React, { useState, useContext, useEffect } from 'react';
import { AppContext } from '../App';
import './TracerTool.css';
import './EB2.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const EB2 = () => {
  const { formData, updateFormData, pageQuestionNumbers, setPageQuestionNumbers, handleNext, handleBack } = useContext(AppContext);
  const [localFormData, setLocalFormData] = useState({
    honors: [],
    furtherStudies: '',
    additionalEducation: '',
    otherHonor: '',
    otherFurtherStudies: '',
  });

  // Determine the current question number for this page
  const questionNumber = pageQuestionNumbers[2] || 4; 

  useEffect(() => {
    // Initialize localFormData with formData from context
    setLocalFormData({
      honors: formData.honors || [],
      furtherStudies: formData.furtherStudies || '',
      additionalEducation: formData.additionalEducation || '',
      otherHonor: formData.otherHonor || '',
      otherFurtherStudies: formData.otherFurtherStudies || '',
    });

    // Set the initial question number for this page if not already set
    if (!pageQuestionNumbers[2]) {
      setPageQuestionNumbers(prev => ({ ...prev, 2: questionNumber }));
    }
  }, [formData]);

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    const updatedHonors = checked
      ? [...localFormData.honors, value]
      : localFormData.honors.filter(honor => honor !== value);

    setLocalFormData(prev => ({
      ...prev,
      honors: updatedHonors,
    }));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setLocalFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const isFormComplete = () => {
    if (!localFormData.furtherStudies) return false;
    return localFormData.furtherStudies !== 'Other' || (localFormData.furtherStudies === 'Other' && localFormData.otherFurtherStudies.trim() !== '');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isFormComplete()) {
      alert('Please complete all required fields before proceeding.');
      return;
    }

    updateFormData({
      honors: localFormData.honors,
      furtherStudies: localFormData.furtherStudies,
      additionalEducation: localFormData.additionalEducation,
      otherHonor: localFormData.otherHonor,
      otherFurtherStudies: localFormData.otherFurtherStudies,
    });

    // Update the question number for the next page before navigating
    setPageQuestionNumbers(prev => ({ ...prev, 3: questionNumber + 3 }));

    handleNext();
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>Educational Background</h1>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="question">
              <p>{questionNumber}. Honors or Awards Received, if any:</p>
              <label>
                <input
                  type="checkbox"
                  value="Cum Laude"
                  checked={localFormData.honors.includes('Cum Laude')}
                  onChange={handleCheckboxChange}
                />{' '}
                Cum Laude
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Magna Cum Laude"
                  checked={localFormData.honors.includes('Magna Cum Laude')}
                  onChange={handleCheckboxChange}
                />{' '}
                Magna Cum Laude
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Summa Cum Laude"
                  checked={localFormData.honors.includes('Summa Cum Laude')}
                  onChange={handleCheckboxChange}
                />{' '}
                Summa Cum Laude
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Don Mariano Jhocson Memorial Award"
                  checked={localFormData.honors.includes('Don Mariano Jhocson Memorial Award')}
                  onChange={handleCheckboxChange}
                />{' '}
                Don Mariano Jhocson Memorial Award
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Loyalty Award"
                  checked={localFormData.honors.includes('Loyalty Award')}
                  onChange={handleCheckboxChange}
                />{' '}
                Loyalty Award
              </label>
              <label>
                <input
                  type="checkbox"
                  value="Other"
                  checked={localFormData.honors.includes('Other')}
                  onChange={(e) => {
                    handleCheckboxChange(e);
                    if (!e.target.checked) {
                      setLocalFormData((prev) => ({ ...prev, otherHonor: '' }));
                    }
                  }}
                />{' '}
                Others
              </label>
              {localFormData.honors.includes('Other') && (
                <input
                  type="text"
                  name="otherHonor"
                  value={localFormData.otherHonor}
                  onChange={handleInputChange}
                  placeholder="Please specify"
                />
              )}
            </div>

            <div className="question">
              <p>{questionNumber + 1}. Further studies you are currently pursuing *</p>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Master's"
                  checked={localFormData.furtherStudies === "Master's"}
                  onChange={handleInputChange}
                  required
                />{' '}
                Master's
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Doctoral"
                  checked={localFormData.furtherStudies === 'Doctoral'}
                  onChange={handleInputChange}
                  required
                />{' '}
                Doctoral
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Another Baccalaureate Degree"
                  checked={localFormData.furtherStudies === 'Another Baccalaureate Degree'}
                  onChange={handleInputChange}
                  required
                />{' '}
                Another Baccalaureate Degree
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Bachelor of Laws"
                  checked={localFormData.furtherStudies === 'Bachelor of Laws'}
                  onChange={handleInputChange}
                  required
                />{' '}
                Bachelor of Laws
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Graduate Diploma/Certificate"
                  checked={localFormData.furtherStudies === 'Graduate Diploma/Certificate'}
                  onChange={handleInputChange}
                  required
                />{' '}
                Graduate Diploma/Certificate
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Certification"
                  checked={localFormData.furtherStudies === 'Certification'}
                  onChange={handleInputChange}
                  required
                />{' '}
                Certification
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="None"
                  checked={localFormData.furtherStudies === 'None'}
                  onChange={handleInputChange}
                  required
                />{' '}
                None
              </label>
              <label>
                <input
                  type="radio"
                  name="furtherStudies"
                  value="Other"
                  checked={localFormData.furtherStudies === 'Other'}
                  onChange={(e) => {
                    handleInputChange(e);
                    if (e.target.checked) {
                      setLocalFormData((prev) => ({ ...prev, otherFurtherStudies: '' }));
                    }
                  }}
                  required
                />{' '}
                Others
              </label>
              {localFormData.furtherStudies === 'Other' && (
                <input
                  type="text"
                  name="otherFurtherStudies"
                  value={localFormData.otherFurtherStudies}
                  onChange={handleInputChange}
                  placeholder="Please specify"
                  required
                />
              )}
            </div>

            <div className="question">
              <p>
                {questionNumber + 2}. (If none or others), Please share any additional education or
                certifications you have completed, including program name/title, completion year, and
                institution attended.{' '}
              </p>
              <textarea
                name="additionalEducation"
                value={localFormData.additionalEducation}
                onChange={handleInputChange}
                placeholder="Enter your answer"
              />
            </div>

            <div className="button-container">
              <div className="back-button-container">
                <button type="button" onClick={handleBack}>
                  Back
                </button>
              </div>
              <div className="next-button-container">
                <button type="submit" disabled={!isFormComplete()}>
                  Next
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EB2;