import React, { useState, useEffect, useContext, useRef } from 'react';
import { AppContext } from '../App';
import './TracerTool.css';
import './EB1.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const EB1 = () => {
  const { formData, updateFormData, pageQuestionNumbers, setPageQuestionNumbers, handleNext, handleBack } = useContext(AppContext);
  const [showSHSTrack, setShowSHSTrack] = useState(false);
  const [showCustomDegree, setShowCustomDegree] = useState(false);
  const [formError, setFormError] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const degreeDropdownRef = useRef(null);

  // Determine the current question number for this page
  const questionNumber = pageQuestionNumbers[1] || 1;

  useEffect(() => {
    let isMounted = true;

    // Reset form data when the component mounts
    updateFormData({
      hsGraduate: '',
      shsTrack: '',
      degree: '',
      yearGraduate: '',
      customDegree: '',
    });
    setShowSHSTrack(false);
    setShowCustomDegree(false);
    setFormError('');

    // Set the initial question number for this page
    setPageQuestionNumbers(prev => ({ ...prev, 1: 1 }));

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    const currentFormData = {
      hsGraduate: formData.hsGraduate || '',
      shsTrack: formData.shsTrack || '',
      degree: formData.degree || '',
      yearGraduate: formData.yearGraduate || '',
      customDegree: formData.customDegree || '',
    };
    setShowSHSTrack(currentFormData.hsGraduate !== '' && currentFormData.hsGraduate !== 'No');
    setShowCustomDegree(currentFormData.degree === 'Other');
  }, [formData]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    let updatedFormData = { ...formData, [name]: value };

    if (name === 'hsGraduate') {
      setShowSHSTrack(value !== 'No');
      if (value === 'No') {
        updatedFormData.shsTrack = '';
      }
    } else if (name === 'degree') {
      setShowCustomDegree(value === 'Other');
      if (value !== 'Other') {
        updatedFormData.customDegree = '';
      }
    }

    updateFormData(updatedFormData);
    setFormError('');
  };

  const isFormComplete = () => {
    const { hsGraduate, degree, yearGraduate, customDegree } = formData;
    if (!hsGraduate || !degree || !yearGraduate) return false;
    if (degree === 'Other' && !customDegree) return false;
    if (showSHSTrack && !formData.shsTrack) return false;
    return true;
  };

  // Calculate the next question number based on the current form state
  const calculateNextQuestionNumber = () => {
    let nextQuestionNumber = 1; // Start at 1 for the first question
    if (formData.hsGraduate) {
      nextQuestionNumber++;
    }
    if (showSHSTrack) {
      nextQuestionNumber++;
    }
    if (formData.degree) {
      nextQuestionNumber++;
    }
    if (showCustomDegree) {
      nextQuestionNumber++;
    }
    if (formData.yearGraduate) {
      nextQuestionNumber++;
    }
    return nextQuestionNumber;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isFormComplete()) {
      setFormError('Please complete all required fields before proceeding.');
      return;
    }

    // Update the question number for the next page before navigating
    const nextQuestionNumber = calculateNextQuestionNumber();
    setPageQuestionNumbers(prev => ({ ...prev, 2: nextQuestionNumber }));

    handleNext();
  };

  const handleDropdownToggle = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleDropdownBlur = () => {
    setIsDropdownOpen(false); // Close the dropdown when it loses focus
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>Educational Background</h1>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="question">
              <p>{questionNumber}. Are you a High School/Senior High School graduate of an NU School? *</p>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="NSNU Senior High School"
                  checked={formData.hsGraduate === 'NSNU Senior High School'}
                  onChange={handleInputChange}
                />{' '}
                NSNU Senior High School
              </label>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="Other NU Campuses"
                  checked={formData.hsGraduate === 'Other NU Campuses'}
                  onChange={handleInputChange}
                />{' '}
                Senior High School of Other NU Campuses
              </label>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="NU High School"
                  checked={formData.hsGraduate === 'NU High School'}
                  onChange={handleInputChange}
                />{' '}
                NU High School
              </label>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="No"
                  checked={formData.hsGraduate === 'No'}
                  onChange={handleInputChange}
                />{' '}
                No
              </label>
            </div>

            {showSHSTrack && (
              <div className="question">
                <p>{questionNumber + 1}. SHS Track *</p>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="ABM"
                    checked={formData.shsTrack === 'ABM'}
                    onChange={handleInputChange}
                  />{' '}
                  Accountancy, Business, Management (ABM)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="STEM"
                    checked={formData.shsTrack === 'STEM'}
                    onChange={handleInputChange}
                  />{' '}
                  Science, Technology, Engineering & Mathematics (STEM)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="HUMSS"
                    checked={formData.shsTrack === 'HUMSS'}
                    onChange={handleInputChange}
                  />{' '}
                  Humanities & Social Sciences (HUMSS)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="GAS"
                    checked={formData.shsTrack === 'GAS'}
                    onChange={handleInputChange}
                  />{' '}
                  General Academic Strand (GAS)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="Sports Track"
                    checked={formData.shsTrack === 'Sports Track'}
                    onChange={handleInputChange}
                  />{' '}
                  Sports Track
                </label>
              </div>
            )}

            <div className="question" ref={degreeDropdownRef}>
              <p>{showSHSTrack ? questionNumber + 2 : questionNumber + 1}. Degree Completed at National University *</p>
              <div className={`dropdown-container ${isDropdownOpen ? 'upward' : ''}`}>
                <select 
                  name="degree" 
                  value={formData.degree || ''} 
                  onChange={handleInputChange} 
                  onFocus={handleDropdownToggle}
                  onBlur={handleDropdownBlur}
                  required
                >
                  <option value="">Select</option>
                  <option value="BS CS with Specialization in Digital Forensics">BS CS with Specialization in Digital Forensics</option>
                  <option value="BS CS with Specialization in Machine Learning">BS CS with Specialization in Machine Learning</option>
                  <option value="BS IT with Specialization in Mobile and Web Applications">BS IT with Specialization in Mobile and Web Applications</option>
                  <option value="BS IT with Specialization in Multimedia Arts and Animation">BS IT with Specialization in Multimedia Arts and Animation</option>
                  <option value="Associate in Computer Technology">Associate in Computer Technology</option>
                  <option value="Master in IT">Master in IT</option>
                  <option value="Master of Science in CS">Master of Science in CS</option>
                  <option value="Doctor of Philosophy in CS">Doctor of Philosophy in CS</option>
                </select>
              </div>
              {showCustomDegree && (
                <input
                  type="text"
                  name="customDegree"
                  value={formData.customDegree || ''}
                  placeholder="Enter your answer"
                  onChange={handleInputChange}
                  required
                />
              )}
            </div>

            <div className="question">
              <p>{showSHSTrack ? questionNumber + 3 : questionNumber + 2}. Year graduate at NU (e.g., 2013, 2017, 2022, etc) *</p>
              <input
                type="text"
                name="yearGraduate"
                value={formData.yearGraduate || ''}
                placeholder="The value must be a number"
                onChange={handleInputChange}
                required
              />
            </div>

            {formError && <p className="error">{formError}</p>}
            <div className="button-container">
              <div className="back-button-container">
                <button type="button" onClick={handleBack}>
                  Back
                </button>
              </div>
              <div className="next-button-container">
                <button type="submit" disabled={!isFormComplete()}>
                  Next
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EB1;