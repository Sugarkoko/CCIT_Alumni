import React, { useState, useContext, useEffect } from 'react';
import { AppContext } from '../App';
import './TracerTool.css';
import './EB3.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const EB3 = () => {
  const { formData, updateFormData, pageQuestionNumbers, setPageQuestionNumbers, handleNext, handleBack } = useContext(AppContext);
  const [localFormData, setLocalFormData] = useState({
    furtherStudiesDetails: '',
    additionalCertifications: '',
    professionalOrganization: '',
    governmentOrganization: '',
  });

  // Determine the current question number for this page
  const questionNumber = pageQuestionNumbers[3] || 7;

  useEffect(() => {
    // Initialize localFormData with formData from context
    setLocalFormData({
      furtherStudiesDetails: formData.furtherStudiesDetails || '',
      additionalCertifications: formData.additionalCertifications || '',
      professionalOrganization: formData.professionalOrganization || '',
      governmentOrganization: formData.governmentOrganization || '',
    });

    // Set the initial question number for this page if not already set
    if (!pageQuestionNumbers[3]) {
      setPageQuestionNumbers(prev => ({ ...prev, 3: questionNumber }));
    }
  }, [formData]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setLocalFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const isFormComplete = () => {
    return localFormData.furtherStudiesDetails.trim() !== '' && localFormData.professionalOrganization.trim() !== '';
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isFormComplete()) {
      alert('Please complete all required fields before proceeding.');
      return;
    }

    updateFormData({
      furtherStudiesDetails: localFormData.furtherStudiesDetails,
      additionalCertifications: localFormData.additionalCertifications,
      professionalOrganization: localFormData.professionalOrganization,
      governmentOrganization: localFormData.governmentOrganization,
    });

    // Handle final submission or navigation as needed
    // setPageQuestionNumbers(prev => ({ ...prev, 4: questionNumber + 3 }));
    handleNext();
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>Educational Background</h1>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="question">
              <p>
                {questionNumber}. (If you have), Please provide the details of further studies being
                pursued (name of program, school/training institution, expected date of completion) *
              </p>
              <textarea
                name="furtherStudiesDetails"
                value={localFormData.furtherStudiesDetails}
                onChange={handleInputChange}
                placeholder="Enter your answer"
                required
              />
            </div>

            <div className="question">
              <p>
                {questionNumber + 1}. Please provide the name of your professional organization and your
                position, if any. *
              </p>
              <textarea
                name="professionalOrganization"
                value={localFormData.professionalOrganization}
                onChange={handleInputChange}
                placeholder="Enter your answer"
                required
              />
            </div>

            <div className="question">
              <p>
                {questionNumber + 2}. Please provide the name of your government organization and
                your position, if any.
              </p>
              <textarea
                name="governmentOrganization"
                value={localFormData.governmentOrganization}
                onChange={handleInputChange}
                placeholder="Enter your answer"
              />
            </div>

            <div className="button-container">
              <div className="back-button-container">
                <button type="button" onClick={handleBack}>
                  Back
                </button>
              </div>
              <div className="next-button-container">
                <button type="submit" disabled={!isFormComplete()}>
                  Next
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EB3;