import React, { useState, useEffect, createContext } from 'react';
import TracerTool from './Components/TracerTool';
import EB1 from './Components/EB1';
import EB2 from './Components/EB2';
import EB3 from './Components/EB3';

// 1. Create the context first
const AppContext = createContext();

function App() {
  const [page, setPage] = useState(0);
  const [formData, setFormData] = useState({});

  // State to track the question number for each page
  const [pageQuestionNumbers, setPageQuestionNumbers] = useState({});

  const updateFormData = (newData) => {
    setFormData(prevData => ({ ...prevData, ...newData }));
  };

  const handleNext = () => {
    setPage(prevPage => prevPage + 1);
  };

  const handleBack = () => {
    setPage(prevPage => prevPage - 1);
  };

  const contextValue = {
    formData,
    updateFormData,
    pageQuestionNumbers, // Pass this to the context
    setPageQuestionNumbers, // Pass this to the context as well
    handleNext,
    handleBack
  };

  return (
    <AppContext.Provider value={contextValue}>
      <div>
        {page === 0 && <TracerTool onFormComplete={() => setPage(1)} />}
        {page === 1 && <EB1 />}
        {page === 2 && <EB2 />}
        {page === 3 && <EB3 />}
      </div>
    </AppContext.Provider>
  );
}

// 2. Export AppContext along with the App component as named exports
export { AppContext };

export default App;