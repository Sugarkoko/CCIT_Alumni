import React, { useState } from 'react';
import './TracerTool.css';
import './EB1.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const EB1 = ({ onBack, onNext }) => {
  const [formData, setFormData] = useState({
    hsGraduate: '',
    shsTrack: '',
    degree: '',
    yearGraduate: '',
    customDegree: '', 
  });

  const [showSHSTrack, setShowSHSTrack] = useState(false); 
  const [showCustomDegree, setShowCustomDegree] = useState(false); 
  const [formError, setFormError] = useState(''); 

  const handleInputChange = (event) => {
    const { name, value } = event.target;

    if (name === 'hsGraduate') {
      setShowSHSTrack(value !== 'No'); 
      setFormData((prevData) => ({
        ...prevData,
        hsGraduate: value,
        shsTrack: value === 'No' ? '' : prevData.shsTrack, 
      }));
    } else if (name === 'degree') {
      setShowCustomDegree(value === 'Other'); 
      setFormData((prevData) => ({
        ...prevData,
        degree: value,
        customDegree: value === 'Other' ? '' : prevData.customDegree, 
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }

    setFormError(''); 
  };

  const isFormComplete = () => {
    const { hsGraduate, degree, yearGraduate, customDegree } = formData;
    if (!hsGraduate || !degree || !yearGraduate) return false;
    if (degree === 'Other' && !customDegree) return false; 
    if (showSHSTrack && !formData.shsTrack) return false;
    return true;
  };

  const calculateLastQuestionNumber = () => {
    let questionNumber = 2; 
    if (showSHSTrack) questionNumber++; 
    if (showCustomDegree) questionNumber++; 
    return questionNumber;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isFormComplete()) {
      setFormError('Please complete all required fields before proceeding.');
      return;
    }
    console.log('Form submitted:', formData);
    onNext(calculateLastQuestionNumber()); 
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>Educational Background</h1>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="question">
              <p>1. Are you a High School/Senior High School graduate of an NU School? *</p>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="NSNU Senior High School"
                  onChange={handleInputChange}
                />{' '}
                NSNU Senior High School
              </label>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="Other NU Campuses"
                  onChange={handleInputChange}
                />{' '}
                Senior High School of Other NU Campuses
              </label>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="NU High School"
                  onChange={handleInputChange}
                />{' '}
                NU High School
              </label>
              <label>
                <input
                  type="radio"
                  name="hsGraduate"
                  value="No"
                  onChange={handleInputChange}
                />{' '}
                No
              </label>
            </div>

            {showSHSTrack && (
              <div className="question">
                <p>2. SHS Track *</p>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="ABM"
                    onChange={handleInputChange}
                  />{' '}
                  Accountancy, Business, Management (ABM)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="STEM"
                    onChange={handleInputChange}
                  />{' '}
                  Science, Technology, Engineering & Mathematics (STEM)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="HUMSS"
                    onChange={handleInputChange}
                  />{' '}
                  Humanities & Social Sciences (HUMSS)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="GAS"
                    onChange={handleInputChange}
                  />{' '}
                  General Academic Strand (GAS)
                </label>
                <label>
                  <input
                    type="radio"
                    name="shsTrack"
                    value="Sports Track"
                    onChange={handleInputChange}
                  />{' '}
                  Sports Track
                </label>
              </div>
            )}

            <div className="question">
              <p>{showSHSTrack ? '3.' : '2.'} Degree Completed at National University *</p>
              <select name="degree" value={formData.degree} onChange={handleInputChange} required>
                <option value="">Select</option>
                <option value="Degree 1">Associate in Computer Technology</option>
                <option value="Degree 2">BA Communication</option>
                <option value="Degree 3">BA English / BA English Language Studies</option>
                <option value="Degree 4">BA Political Science</option>
                <option value="Degree 5">Bachelor of Elementary Education</option>
                <option value="Degree 6">Bachelor of Physical Education</option>
                <option value="Degree 7">Bachelor of Secondary Education major in English</option>
                <option value="Degree 8">Bachelor of Secondary Education major in Math</option>
                <option value="Degree 9">BS Accountancy</option>
                <option value="Degree 10">BS Accounting Information System</option>
                <option value="Degree 11">BS Architecture</option>
                <option value="Degree 12">BSBA major in Financial Management</option>
                <option value="Degree 13">BSBA major in Human Resource Management</option>
                <option value="Degree 14">BSBA major in Marketing Management</option>
                <option value="Degree 15">BS Civil Engineering</option>
                <option value="Degree 16">BS Computer Engineering</option>
                <option value="Degree 17">BS Computer Science</option>
                <option value="Degree 18">BS Electrical Engineering</option>
                <option value="Degree 19">BS Electronics Engineering</option>
                <option value="Degree 20">BS Environmental and Sanitary Engineering</option>
                <option value="Degree 21">BS Environmental Planning</option>
                <option value="Degree 22">BS Hospitality Management / BS HRM</option>
                <option value="Degree 23">BS Information Technology</option>
                <option value="Degree 24">BS Management Accounting</option>
                <option value="Degree 25">BS Mechanical Engineering</option>
                <option value="Degree 26">BS Medical Technology / Medical Laboratory Science</option>
                <option value="Degree 27">BS Nursing</option>
                <option value="Degree 28">BS Pharmacy</option>
                <option value="Degree 29">BS Psychology</option>
                <option value="BS Real Estate Management">BS Real Estate Management</option>
                <option value="BS Tourism Management">BS Tourism Management</option>
                <option value="Doctoral of Dental Medicine">Doctoral of Dental Medicine</option>
                <option value="Doctor of Education">Doctor of Education</option>
                <option value="MA Education">MA Education</option>
                <option value="Master in Information Technology">Master in Information Technology</option>
                <option value="MS Computer Science">MS Computer Science</option>
                <option value="MS Sanitary Engineering">MS Sanitary Engineering</option>
                <option value="PhD Computer Science">PhD Computer Science</option>
                <option value="Other">Other</option>
              </select>
              {showCustomDegree && (
                <input
                  type="text"
                  name="customDegree"
                  value={formData.customDegree}
                  placeholder="Enter your answer"
                  onChange={handleInputChange}
                  required
                />
              )}
            </div>

            <div className="question">
              <p>{showSHSTrack ? '4.' : '3.'} Year graduate at NU (e.g., 2013, 2017, 2022, etc) *</p>
              <input
                type="text"
                name="yearGraduate"
                value={formData.yearGraduate}
                placeholder="The value must be a number"
                onChange={handleInputChange}
                required
              />
            </div>

            {formError && <p className="error">{formError}</p>}
            <div className="button-container">
              <div className="back-button-container">
                <button type="button" onClick={onBack}>
                  Back
                </button>
              </div>
              <div className="next-button-container">
                <button type="submit" disabled={!isFormComplete()}>
                  Next
                </button>

              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EB1;
