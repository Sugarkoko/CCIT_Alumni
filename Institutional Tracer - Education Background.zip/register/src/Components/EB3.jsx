import React, { useState } from 'react';
import './TracerTool.css';
import './EB3.css';
import backgroundImage from '../assets/Background.jpeg';
import logo from '../assets/Blue Logo.png';

const EB3 = ({ onBack, onNext }) => {
  const [formData, setFormData] = useState({
    furtherStudiesDetails: '',
    additionalCertifications: '',
    professionalOrganization: '',
    governmentOrganization: '',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const isFormComplete = () =>
    formData.furtherStudiesDetails.trim() !== '' &&
    formData.professionalOrganization.trim() !== '';

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isFormComplete()) {
      alert('Please complete all required fields before proceeding.');
      return;
    }
    console.log('Form submitted:', formData);
    onNext();
  };

  return (
    <div className="tracer-tool" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay">
        <div className="content">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <h1>Educational Background</h1>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="question">
              <p>18. (If you have), Please provide the details of further studies being pursued (name of program, school/training institution, expected date of completion) *</p>
              <textarea
                name="furtherStudiesDetails"
                value={formData.furtherStudiesDetails}
                onChange={handleInputChange}
                placeholder="Enter your answer"
                required
              />
            </div>

            <div className="question">
              <p>20. Please provide the name of your professional organization and your position, if any. *</p>
              <textarea
                name="professionalOrganization"
                value={formData.professionalOrganization}
                onChange={handleInputChange}
                placeholder="Enter your answer"
                required
              />
            </div>

            <div className="question">
              <p>21. Please provide the name of your government organization and your position, if any.</p>
              <textarea
                name="governmentOrganization"
                value={formData.governmentOrganization}
                onChange={handleInputChange}
                placeholder="Enter your answer"
              />
            </div>

            <div className="button-container">
              <div className="back-button-container">
                <button type="button" onClick={onBack}>
                  Back
                </button>
              </div>
              <div className="next-button-container">
                <button type="submit" disabled={!isFormComplete()}>
                  Next
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EB3;