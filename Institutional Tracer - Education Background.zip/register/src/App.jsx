import React, { useState } from 'react';
import TracerTool from './Components/TracerTool';
import EB1 from './Components/EB1';
import EB2 from './Components/EB2';
import EB3 from './Components/EB3';

const App = () => {
  const [currentFrame, setCurrentFrame] = useState('first');

  return (
    <>
      {currentFrame === 'first' && (
        <TracerTool onNext={() => setCurrentFrame('second')} />
      )}
      {currentFrame === 'second' && (
        <EB1
          onBack={() => setCurrentFrame('first')}
          onNext={() => setCurrentFrame('third')}
        />
      )}
      {currentFrame === 'third' && (
        <EB2
          onBack={() => setCurrentFrame('second')}
          onNext={() => setCurrentFrame('fourth')} // Updated to direct to EB3
        />
      )}
      {currentFrame === 'fourth' && (
        <EB3 onBack={() => setCurrentFrame('third')} />
      )}
    </>
  );
};

export default App;
