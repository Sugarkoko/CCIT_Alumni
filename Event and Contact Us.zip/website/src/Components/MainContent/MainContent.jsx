import React from "react";
import "./MainContent.css";
import logo from "../../assets/Blue Logo.png"; // Adjust the path

const MainContent = () => {
  return (
    <main className="main-content">
      <img src={logo} alt="CCIT National University" className="logo" />
      <hr className="logo-line" /> {/* Horizontal line below the logo */}
      <p>
        The Alumni Management System website offers an intuitive and user-friendly platform for CCIT alumni to connect with each other and the university. 
        Featuring a centralized database, real-time notifications, event management tools, and a mentorship matching system, the website ensures seamless 
        interaction and engagement. Alumni can update their profiles, register for events, participate in mentorship programs, and access exclusive benefits, all within a secure and efficient digital environment.
      </p>
      <p>
        It is designed to bridge the gap between the College of Computing and Information Technology (CCIT) alumni and National University-Manila. 
        Its purpose is to streamline communication, enhance engagement, and foster a stronger, more connected alumni network.  By providing a centralized platform for managing alumni data, organizing events, facilitating mentorship opportunities, and showcasing achievements, the system aims to create a vibrant community where alumni can stay informed, contribute to the university, and support the growth of current students.
      </p>
    </main>
  );
};

export default MainContent;
