import React from "react";
import ContactUsHeader from "./ContactUsHeader/ContactUsHeader";
import ContactUsMainContent from "./ContactUsMainContent/ContactUsMainContent";
import ContactUsFooter from "./ContactUsFooter/ContactUsFooter";
import "./ContactUs.css"; 

const ContactUs = () => {
  return (
    <div className="contact-us">
      <ContactUsHeader />
      <ContactUsMainContent />
      <ContactUsFooter />
    </div>
  );
};

export default ContactUs;
