import React from "react";
import "./ContactUsHeader.css";

const ContactUsHeader = () => {
  return (
    <header className="contact-us-header">
    </header>
  );
};

export default ContactUsHeader;
