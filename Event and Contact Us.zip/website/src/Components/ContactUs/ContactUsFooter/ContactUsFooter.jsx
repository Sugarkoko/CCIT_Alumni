import React from "react";
import "./ContactUsFooter.css";

const ContactUsFooter = () => {
  return (
    <footer className="contact-us-footer">
  
    </footer>
  );
};

export default ContactUsFooter;