import React from "react";
import "./ContactUsMainContent.css";

const ContactUsMainContent = () => {
  return (
    <div className="contact-section">
      <div className="contact-container">
        <div className="contact-details">
          <h3>National University</h3>
          <p>📍 551 M.F. Jhocson St. Sampaloc, Manila, PH 1008</p>
          <p>📞 +632 8712-1900</p>
          <p>✉️ info@national-u.edu.ph</p>
        </div>

        <div className="alumni-affairs">
          <h3>Alumni Affairs</h3>
          <p>📞 +632 8563-6991</p>
          <p>✉️ alumni-affairs@national-u.edu.ph</p>
          <p>College of Computing and Information Technologies</p>
          <p>📞 +632 8712-1900</p>
        </div>

        <div className="ccit-contact">
          <h3>College of Computing and Information Technologies</h3>
          <p>📞 +632 8712-1900</p>
        </div>
      </div>

      <div className="contact-divider"></div>

      <div className="location-container">
        <div className="main-content">
          <h3>University Location</h3>
          <p>
            The University can easily be reached from any part of the City of
            Manila by using the ordinary means of transportation.
          </p>
          <p>
            From Quiapo, one may take a jeepney plying the Quiapo Lealtad route
            at Barbosa Street in Quiapo and then alight at a point on F.
            Jhocson: if preferred, one may take a Balic-Balic bound jeepney and
            alight at the corner of G. Tuazon and M. F. Jhocson Streets.
          </p>
          <p>
            The University may also be reached by way of España Street from
            points North or Northwest through Cayco Street, then turn right
            through F. Jhocson Street to M. F. Jhocson Street; from points
            Northwest through Earnshaw Street, turn left through Cayco then
            right through F. Jhocson to M. F. Jhocson.
          </p>
          <p>
            From Antipolo, Cainta, Marikina, Pasig, and surrounding communities,
            the University can be reached by taking the LRT Marikina Santolan
            Station and alight at the Legarda Station, then proceed towards the
            Sampaloc church, turn right to F. Jhocson Street.
          </p>
        </div>

      <div className="map-container">
          <iframe
           src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3858.045412571616!2d120.98985731485862!3d14.607751489793033!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b610d7ec7edb%3A0x7c2b7d8f9e332d9b!2s551%20M.F.%20Jhocson%20St.%2C%20Sampaloc%2C%20Manila%2C%20PH%201008!5e0!3m2!1sen!2sph!4v1618305532061!5m2!1sen!2sph"
           width="100%"
           height="400"
           style={{ border: 0 }}
           allowFullScreen=""
          loading="lazy"
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default ContactUsMainContent;

