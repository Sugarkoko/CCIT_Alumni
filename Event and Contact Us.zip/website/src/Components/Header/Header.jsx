import React from "react";
import { Link as ScrollLink } from "react-scroll";
import { Link as RouterLink } from "react-router-dom";
import "./Header.css";
import WhiteLogo from "../../assets/White Logo.png"; 

const Header = () => {
  return (
    <header className="header">
      <div className="header-container">
        <div className="header-logo">
          <img src={WhiteLogo} alt="Logo" />
        </div>
        <div className="header-title">
          COLLEGE OF COMPUTING AND INFORMATION TECHNOLOGIES ALUMNI
        </div>
      </div>
      <nav className="header-nav">
        <ul>
          <li><RouterLink to="/about">Home</RouterLink></li>
          <li>
            <ScrollLink to="about" smooth={true} duration={500}>About us</ScrollLink>
          </li>
          <li>
            <ScrollLink to="events" smooth={true} duration={500}>Events</ScrollLink>
          </li>
          <li>
            <ScrollLink to="achievements" smooth={true} duration={500}>Achievements</ScrollLink>
          </li>
          <li><RouterLink to="/contact">Contact us</RouterLink></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
