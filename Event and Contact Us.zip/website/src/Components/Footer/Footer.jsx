import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-section">
        <p>© 2024 CCIT Alumni Connect. All rights reserved.</p>
        <p>Privacy Policy</p>
      </div>
      <div className="footer-section">
        <p>College of Computing and Information Technologies</p>
        <p>📞 +632 8712-1900</p>
      </div>
      <div className="footer-section">
        <p>Alumni Affairs</p>
        <p>📞 +632 8563-6991</p>
        <p>📧 alumni-affairs@national-u.edu.ph</p>
      </div>
    </footer>
  );
};

export default Footer;
