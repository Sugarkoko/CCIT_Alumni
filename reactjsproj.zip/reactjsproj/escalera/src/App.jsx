import React from 'react';
import Header from './components/Header';
import Body from './components/Body';
import EventsBody from './components/EventsBody';
import Footer from './components/Footer';
import AchBody from './components/AchBody';
import AboutBody from './components/AboutBody';
import ContactBody from './components/ContactBody';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <Routes>
          <Route path="/" element={<Body />} />
          <Route path="/events" element={<EventsBody />} />
          <Route path="/achievements" element={<AchBody />} />
          <Route path="/about" element={<AboutBody />} />
          <Route path="/contact" element={<ContactBody />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
