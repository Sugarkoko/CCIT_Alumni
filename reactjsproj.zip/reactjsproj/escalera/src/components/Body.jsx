import React from 'react';
import { useNavigate } from "react-router-dom";
import './Body.css';

const Body = () => {
  const navigate = useNavigate();
  return (
    <div>
    <main className="body">
      <section className="content">
        <h2>Welcome to National University Alumni Portal</h2>
        <p>Join us and stay connected with the CCIT alumni community.</p>
        <div className="buttons">
          <button className="join-btn">Join Now!</button>
          <button className="login-btn">Login</button>
        </div>
      </section>
    </main>
    </div>
  );
};

export default Body;