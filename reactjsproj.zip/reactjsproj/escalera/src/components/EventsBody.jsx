import React from 'react';
import './EventsBody.css'; 

const EventsBody = () => {
  return (
    <div className="events-body-container">
      <h1 className="events-title">Join the CCIT Alumni Connect Community!</h1>
      <p className="events-description">
        Access to the Events Page is limited to verified alumni members. Want to stay connected and see what's happening? <span className="register-link">Register</span> as an alumni member today!
      </p>
      <button className="join-button">Join Now!</button>
      <p className="login-text">
        Already a member? <span className="login-link">Login</span>
      </p>
    </div>
  );
};

export default EventsBody;
